﻿using System.Diagnostics.CodeAnalysis;
using Autofac;
using Idasen.BluetoothLE.Desk.Characteristics;
using Idasen.BluetoothLE.Desk.Characteristics.Factories;
using Idasen.BluetoothLE.Desk.Common;
using Idasen.BluetoothLE.Desk.Interfaces;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics.Factories;
using Idasen.BluetoothLE.Desk.Interfaces.Common;

namespace Idasen.BluetoothLE.Desk
{
    // ReSharper disable once InconsistentNaming
    [ExcludeFromCodeCoverage]
    public class BluetoothLEDeskModule
        : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<BluetoothLEModule>();

            builder.RegisterType<AllGattCharacteristicsProvider>()
                   .As<IAllGattCharacteristicsProvider>();

            builder.RegisterType<CustomGattCharacteristicProvider>()
                   .As<ICustomGattCharacteristicProvider>();

            builder.RegisterType<CustomGattCharacteristicsProviderFactory>()
                   .As<ICustomGattCharacteristicsProviderFactory>();

            builder.RegisterType<RawValueReader>()
                   .As<IRawValueReader>();

            builder.RegisterType<RawValueWriter>()
                   .As<IRawValueWriter>();

            builder.RegisterType<GenericAccess>()
                   .As<IGenericAccess>();

            builder.RegisterType<GenericAccessFactory>()
                   .As<IGenericAccessFactory>();

            builder.RegisterType<GenericAttribute>()
                   .As<IGenericAttribute>();

            builder.RegisterType<GenericAttributeFactory>()
                   .As<IGenericAttributeFactory>();

            builder.RegisterType<ReferenceInput>()
                   .As<IReferenceInput>();

            builder.RegisterType<ReferenceInputFactory>()
                   .As<IReferenceInputFactory>();

            builder.RegisterType<ReferenceOutput>()
                   .As<IReferenceOutput>();

            builder.RegisterType<ReferenceOutputFactory>()
                   .As<IReferenceOutputFactory>();

            builder.RegisterType<Dpg>()
                   .As<IDpg>();

            builder.RegisterType<DpgFactory>()
                   .As<IDpgFactory>();

            builder.RegisterType<Control>()
                   .As<IControl>();

            builder.RegisterType<ControlFactory>()
                   .As<IControlFactory>();

            builder.RegisterType<DeskCharacteristics>()
                   .As<IDeskCharacteristics>();

            builder.RegisterType<Desk>()
                   .As<IDesk>();

            builder.RegisterType<DeskFactory>()
                   .As<IDeskFactory>();
        }
    }
}