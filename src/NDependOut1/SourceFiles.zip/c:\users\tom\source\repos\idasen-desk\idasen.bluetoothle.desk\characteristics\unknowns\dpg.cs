﻿using System.Collections.Generic;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknowns
{
    public class Dpg
        : UnknownBase, IDpg
    {
        public IEnumerable<byte> RawDpg { get; } = RawArrayEmpty;
    }
}