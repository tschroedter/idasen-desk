﻿using System;
using System.Collections.Generic;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;
using Idasen.BluetoothLE.Desk.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.Desk.Characteristics
{
    public class GenericAccess
        : CharacteristicBase,
          IGenericAccess
    {
        public delegate IGenericAccess Factory(IDevice device);

        private const string CharacteristicDeviceName = "Device Name";
        private const string CharacteristicAppearance = "Appearance";
        private const string CharacteristicParameters = "Peripheral Preferred Connection Parameters";
        private const string CharacteristicResolution = "Central Address Resolution";

        private readonly IAllGattCharacteristicsProvider _allGattCharacteristicsProvider;

        public GenericAccess(
            ILogger                                   logger,
            IDevice                                   device,
            ICustomGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter,
            [NotNull] IAllGattCharacteristicsProvider allGattCharacteristicsProvider)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
            Guard.ArgumentNotNull(allGattCharacteristicsProvider,
                                  nameof(allGattCharacteristicsProvider));

            _allGattCharacteristicsProvider = allGattCharacteristicsProvider;
        }

        public override Guid GattServiceUuid { get; } = Guid.Parse("00001800-0000-1000-8000-00805F9B34FB");

        public IEnumerable<byte> RawCentralAddressResolution => TryGetValueOrEmpty(CharacteristicResolution);

        public IEnumerable<byte> RawPeripheralPreferredConnectionParameters => TryGetValueOrEmpty(CharacteristicParameters);

        public IEnumerable<byte> RawAppearance => TryGetValueOrEmpty(CharacteristicAppearance);

        public IEnumerable<byte> RawDeviceName => TryGetValueOrEmpty(CharacteristicDeviceName);

        protected override T WithMapping<T>() where T : class
        {
            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicDeviceName,
                                                           out var uuid))
                DescriptionToUuid[CharacteristicDeviceName] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicAppearance,
                                                           out uuid))
                DescriptionToUuid[CharacteristicAppearance] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicParameters,
                                                           out uuid))
                DescriptionToUuid[CharacteristicParameters] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicResolution,
                                                           out uuid))
                DescriptionToUuid[CharacteristicResolution] = uuid;

            return this as T;
        }
    }
}