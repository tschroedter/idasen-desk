﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Idasen.BluetoothLE.Desk.Common
{
    public static class ByteArrayExtensions
    {
        public static string ToHex(this IEnumerable<byte> array)
        {
            return BitConverter.ToString(array.ToArray()); //.Replace("-", "");
        }
    }
}