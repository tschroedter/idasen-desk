﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using Autofac;
using AutofacSerilogIntegration;
using Idasen.BluetoothLE;
using Idasen.BluetoothLE.Desk;
using Idasen.BluetoothLE.Desk.Interfaces;
using Idasen.BluetoothLE.Interfaces.DevicesDiscovery;
using Serilog;
using Serilog.Events;
using static System.Console;

namespace Idasen.ConsoleApp
{
    internal sealed class Program
    {
        private static ILogger      Logger;
        private static IDeskFactory DeskFactory;
        private static IDesk        Desk;

        [SuppressMessage("NDepend",
                         "ND1006:AvoidMethodsPotentiallyPoorlyCommented",
                         Justification = "Test Console Application")]
        private static void Main()
        {
            const string template =
                "[{Timestamp:HH:mm:ss.ffff} {Level:u3}] {Message}{NewLine}{Exception}";
            // "[{Timestamp:HH:mm:ss.ffff} {Level:u3}] {Message} (at {Caller}){NewLine}{Exception}";

            Log.Logger = new LoggerConfiguration()
                        .Enrich.WithCaller()
                        .MinimumLevel.Information()
                        .WriteTo.ColoredConsole(LogEventLevel.Debug, template)
                        .CreateLogger();

            var builder = new ContainerBuilder();

            builder.RegisterLogger();
            builder.RegisterModule<BluetoothLEModule>();
            builder.RegisterModule<BluetoothLEDeskModule>();

            var container = builder.Build();

            Logger = container.Resolve<ILogger>();

            DeskFactory = container.Resolve<IDeskFactory>();

            var monitor = container.Resolve<IDeviceMonitorWithExpiry>();

            var updated     = monitor.DeviceUpdated.Subscribe(OnDeviceUpdated);
            var discovered  = monitor.DeviceDiscovered.Subscribe(OnDeviceDiscovered);
            var nameChanged = monitor.DeviceNameUpdated.Subscribe(OnDeviceNameChanged);
            var deskFound = monitor.DeviceNameUpdated
                                   .Where(device => device.Name.StartsWith("Desk") ||
                                                    device.Address == 250635178951455)
                                   .Subscribe(OnDeskDiscovered);

            monitor.Start();

            ReadLine();

            monitor.Stop();

            deskFound.Dispose();
            nameChanged.Dispose();
            discovered.Dispose();
            updated.Dispose();

            container.Dispose();
        }

        internal static async void OnDeskDiscovered(IDevice device)
        {
            if (Desk != null)
                return;

            try
            {
                Desk = await DeskFactory.CreateAsync(device.Address);
                Desk.Connect();
            }
            catch (Exception e)
            {
                WriteLine(e);
                throw;
            }
        }

        private static void OnDeviceUpdated(IDevice device)
        {
            Logger.Information($"Device Updated: {device}");
            //Logger.Information($"{DevicesToString(_monitor.DiscoveredDevices)}");
        }

        private static void OnDeviceDiscovered(IDevice device)
        {
            Logger.Information($"Device Discovered: {device}");
        }

        private static void OnDeviceNameChanged(IDevice device)
        {
            Logger.Information($"Device Name Changed: {device}");
        }
    }
}