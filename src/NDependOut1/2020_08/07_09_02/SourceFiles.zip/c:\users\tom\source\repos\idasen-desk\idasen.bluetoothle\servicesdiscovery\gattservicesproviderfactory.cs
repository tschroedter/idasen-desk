﻿using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;

namespace Idasen.BluetoothLE.ServicesDiscovery
{
    public class GattServicesProviderFactory
        : IGattServicesProviderFactory
    {
        private readonly GattServicesProvider.Factory _factory;

        public GattServicesProviderFactory(GattServicesProvider.Factory factory)
        {
            _factory = factory;
        }

        /// <inheritdoc />
        public IGattServicesProvider Create(IBluetoothLeDeviceWrapper wrapper)
        {
            Guard.ArgumentNotNull(wrapper,
                                  nameof(wrapper));

            return _factory.Invoke(wrapper);
        }
    }
}