﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using NotNullAttribute = JetBrains.Annotations.NotNullAttribute;

namespace Idasen.BluetoothLE.ServicesDiscovery.Wrappers
{
    /// <inheritdoc />
    [ExcludeFromCodeCoverage]
    public class GattCharacteristicWrapper
        : IGattCharacteristicWrapper
    {
        public delegate IGattCharacteristicWrapper Factory(GattCharacteristic characteristic);

        private readonly GattCharacteristic _characteristic;    // todo use it

        public GattCharacteristicWrapper(
            [NotNull] GattCharacteristic characteristic)
        {
            Guard.ArgumentNotNull(characteristic,
                                  nameof(characteristic));

            _characteristic = characteristic;
        }

        /// <inheritdoc />
        public Guid Uuid => _characteristic.Uuid;

        /// <inheritdoc />
        public GattCharacteristicProperties CharacteristicProperties => _characteristic.CharacteristicProperties;

        public IReadOnlyList<GattPresentationFormat> PresentationFormats => _characteristic.PresentationFormats;
        public Guid ServiceUuid => _characteristic.Service.Uuid; // maybe inject IGattDeviceServiceWrapper
        public string UserDescription => _characteristic.UserDescription;
        public GattProtectionLevel ProtectionLevel => _characteristic.ProtectionLevel;
        public ushort AttributeHandle => _characteristic.AttributeHandle;

        /// <inheritdoc />
        public async Task<GattWriteResult> WriteValueWithResultAsync(IBuffer buffer)
        {
            return await _characteristic.WriteValueWithResultAsync(buffer);
        }

        /// <inheritdoc />
        public async Task<GattCommunicationStatus> WriteValueAsync(IBuffer buffer)
        {
            return await _characteristic.WriteValueAsync(buffer);
        }

        /// <inheritdoc />
        public Task<GattReadResult> ReadValueAsync()
        {
            return _characteristic.ReadValueAsync()
                                      .AsTask();
        }
    }
}