﻿using System;
using System.Collections.Generic;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;

namespace Idasen.BluetoothLE.ServicesDiscovery
{
    /// <inheritdoc />
    public class Device
        : IDevice
    {
        public delegate IDevice Factory(IBluetoothLeDeviceWrapper wrapper);

        private readonly IDisposable               _subscriber;
        private readonly IBluetoothLeDeviceWrapper _wrapper;

        public Device(IBluetoothLeDeviceWrapper wrapper)
        {
            _wrapper = wrapper;

            _subscriber = _wrapper.ConnectionStatusChanged
                                  .Subscribe(_ => Connect());
        }

        /// <inheritdoc />
        public IObservable<BluetoothConnectionStatus> ConnectionStatusChanged => _wrapper.ConnectionStatusChanged;

        /// <inheritdoc />
        public GattCommunicationStatus GattCommunicationStatus => _wrapper.GattCommunicationStatus;

        /// <inheritdoc />
        public void Connect()
        {
            if (ConnectionStatus == BluetoothConnectionStatus.Connected)
                return;

            _wrapper.Connect();
        }

        /// <inheritdoc />
        public string Name => _wrapper.Name;

        /// <inheritdoc />
        public string DeviceId => _wrapper.DeviceId;

        /// <inheritdoc />
        public bool IsPaired => _wrapper.IsPaired;

        /// <inheritdoc />
        public BluetoothConnectionStatus ConnectionStatus => _wrapper.ConnectionStatus;

        /// <inheritdoc />
        public IReadOnlyDictionary<IGattDeviceServiceWrapper, IGattCharacteristicsResultWrapper> GattServices =>
            _wrapper.GattServices;

        /// <inheritdoc />
        public IObservable<GattCommunicationStatus> GattServicesRefreshed => _wrapper.GattServicesRefreshed;

        /// <inheritdoc />
        public void Dispose()
        {
            _wrapper?.Dispose();
            _subscriber?.Dispose();
        }
    }
}