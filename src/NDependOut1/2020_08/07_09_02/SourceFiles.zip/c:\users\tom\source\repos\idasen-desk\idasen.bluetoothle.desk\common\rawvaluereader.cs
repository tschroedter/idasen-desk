﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Idasen.BluetoothLE.Desk.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.Desk.Common
{
    public class RawValueReader
        : IRawValueReader
    {
        private static readonly byte[] ArrayEmpty = Enumerable.Empty<byte>()
                                                              .ToArray();

        public byte?                   ProtocolError { get; private set; }
        public GattCommunicationStatus Status        { get; private set; }

        public async Task<(bool, byte[])> TryReadValueAsync(
            IGattCharacteristicWrapper characteristic)
        {
            Guard.ArgumentNotNull(characteristic,
                                  nameof(characteristic));

            if (!SupportsRead(characteristic))
                return await ReadValue(characteristic);

            Log.Information($"GattCharacteristic '{characteristic.Uuid}' " +
                            "doesn't support 'Read'");

            return (false, ArrayEmpty);
        }

        private static bool SupportsRead(IGattCharacteristicWrapper characteristic)
        {
            return (characteristic.CharacteristicProperties & GattCharacteristicProperties.Read) !=
                   GattCharacteristicProperties.Read;
        }

        private async Task<(bool, byte[])> ReadValue(
            [NotNull] IGattCharacteristicWrapper characteristic)
        {
            Guard.ArgumentNotNull(characteristic,
                                  nameof(characteristic));

            var readValue = await characteristic.ReadValueAsync();

            ProtocolError = readValue.ProtocolError;
            Status        = readValue.Status;

            var success = GattCommunicationStatus.Success == Status;

            if (GattCommunicationStatus.Success != Status)
                return (false, ArrayEmpty);

            var reader = DataReader.FromBuffer(readValue.Value);
            var bytes  = new byte[reader.UnconsumedBufferLength];
            reader.ReadBytes(bytes);

            return (success, bytes);
        }
    }
}