﻿using System.Collections.Generic;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class ReferenceInput
        : UnknownBase, IReferenceInput
    {
        public IEnumerable<byte> Ctrl1 { get; } = RawArrayEmpty;
    }
}