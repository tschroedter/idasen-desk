﻿using System;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class GenericAccess
        : CharacteristicBase,
          IGenericAccess
    {
        public const string CharacteristicDeviceName = "Device Name";
        public const string CharacteristicAppearance = "Appearance";

        public const string CharacteristicPeripheralPreferredConnectionParameters =
            "Peripheral Preferred Connection Parameters";

        public const     string CharacteristicCentralAddressResolution = "Central Address Resolution";
        private readonly IAllGattCharacteristicsProvider _allGattCharacteristicsProvider;

        public GenericAccess(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider,
            IAllGattCharacteristicsProvider   allGattCharacteristicsProvider)
            : base(logger,
                   gattDeviceService,
                   customGattCharacteristicProvider)
        {
            _allGattCharacteristicsProvider = allGattCharacteristicsProvider;
        }

        public byte[] RawCentralAddressResolution => TryGetValueOrEmpty(CharacteristicCentralAddressResolution);

        public byte[] RawPeripheralPreferredConnectionParameters =>
            TryGetValueOrEmpty(CharacteristicPeripheralPreferredConnectionParameters);

        public byte[] RawAppearance => TryGetValueOrEmpty(CharacteristicAppearance);

        public byte[] RawDeviceName => TryGetValueOrEmpty(CharacteristicDeviceName);

        public override T Initialize<T>() where T : class
        {
            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicDeviceName,
                                                           out var uuid))
                DescriptionToUuid[CharacteristicDeviceName] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicAppearance,
                                                           out uuid))
                DescriptionToUuid[CharacteristicAppearance] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicPeripheralPreferredConnectionParameters,
                                                           out uuid))
                DescriptionToUuid[CharacteristicPeripheralPreferredConnectionParameters] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicCentralAddressResolution,
                                                           out uuid))
                DescriptionToUuid[CharacteristicCentralAddressResolution] = uuid;

            return this as T;
        }
    }
}