﻿using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.KnownDevices.Characteristics.New;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class GenericAttributeFactory
        : IGenericAttributeFactory
    {
        private readonly GenericAttributeNew.Factory _factory;

        public GenericAttributeFactory([NotNull] GenericAttributeNew.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }

        public IGenericAttributeNew Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}