﻿using System;
using System.Text;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class Error
        : CharacteristicBase,
          IError
    {
        private const string KeyError = "Error";

        public Error(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider)
            : base(logger,
                   gattDeviceService,
                   customGattCharacteristicProvider)
        {
        }

        public byte[] RawError => TryGetValueOrEmpty(KeyError);

        public override T Initialize<T>() where T : class
        {
            DescriptionToUuid[KeyError] = Guid.Parse("99FA0031-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}