﻿using Idasen.BluetoothLE.KnownDevices.Characteristics;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class UnknownGenericAccessNew
        : Unknown, IGenericAccessNew
    {
        public byte[] RawCentralAddressResolution                { get; } = RawArrayEmpty;
        public byte[] RawPeripheralPreferredConnectionParameters { get; } = RawArrayEmpty;
        public byte[] RawAppearance                              { get; } = RawArrayEmpty;
        public byte[] RawDeviceName                              { get; } = RawArrayEmpty;
    }
}