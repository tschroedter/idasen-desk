﻿using System;
using Idasen.BluetoothLE.KnownDevices.Characteristics.New;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class UnknownGenericReferenceOutputNew
        : Unknown, IReferenceOutputNew
    {
        public Guid   GattServiceUuid { get; } = Guid.Empty;
        public byte[] RawHeightSpeed  { get; } = RawArrayEmpty;
        public byte[] RawTwo          { get; } = RawArrayEmpty;
        public byte[] RawThree        { get; } = RawArrayEmpty;
        public byte[] RawFour         { get; } = RawArrayEmpty;
        public byte[] RawFive         { get; } = RawArrayEmpty;
        public byte[] RawSix          { get; } = RawArrayEmpty;
        public byte[] RawSeven        { get; } = RawArrayEmpty;
        public byte[] RawEight        { get; } = RawArrayEmpty;
        public byte[] RawMask         { get; } = RawArrayEmpty;
        public byte[] RawDetectMask   { get; } = RawArrayEmpty;
    }
}