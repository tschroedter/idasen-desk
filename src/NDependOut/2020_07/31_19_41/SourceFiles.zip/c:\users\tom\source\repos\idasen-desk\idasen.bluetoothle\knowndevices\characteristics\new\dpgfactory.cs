﻿using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.KnownDevices.Characteristics.New;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class DpgFactory // todo generic factory
        : IDpgFactory
    {
        private readonly DpgNew.Factory _factory;

        public DpgFactory([NotNull] DpgNew.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }
        public IDpgNew Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}