﻿using Idasen.BluetoothLE.KnownDevices.Characteristics.New;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class UnknownGenericReferenceInputNew
        : Unknown, IReferenceInputNew
    {
        public byte[] Ctrl1 { get; } = RawArrayEmpty;
    }
}