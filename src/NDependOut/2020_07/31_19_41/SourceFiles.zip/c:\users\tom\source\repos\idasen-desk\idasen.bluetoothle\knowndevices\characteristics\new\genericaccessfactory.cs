﻿using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class GenericAccessFactory // todo generic factory
        : IGenericAccessFactory
    {
        private readonly GenericAccessNew.Factory _factory;

        public GenericAccessFactory([NotNull] GenericAccessNew.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }
        public IGenericAccessNew Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}