﻿using System.Linq;
using System.Threading.Tasks;
using Idasen.BluetoothLE.KnownDevices.Characteristics;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class Unknown : ICharacteristicBase
    {
        protected static readonly byte[] RawArrayEmpty = Enumerable.Empty<byte>()
                                                                   .ToArray();

        public T Initialize<T>() where T : class
        {
            return this as T;
        }

        public Task Refresh()
        {
            return Task.FromResult(false);
        }
    }
}