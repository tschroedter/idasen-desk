﻿using System;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics.New
{
    public class ReferenceInputNew
        : CharacteristicBaseNew,
          IReferenceInputNew
    {
        private const   string KeyCtrl1 = "Ctrl1";
        private const   string KeyCtrl2 = "Ctrl2";
        private const   string KeyCtrl3 = "Ctrl3";
        private const   string KeyCtrl4 = "Ctrl4";
        public override Guid   GattServiceUuid { get; } = Guid.Parse("99FA0030-338A-1024-8A49-009C0215F78A");

        public delegate IReferenceInputNew Factory(IDevice device);

        public ReferenceInputNew(
            ILogger                                   logger,
            IDevice                                   device,
            ICustomGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
        }


        public byte[] Ctrl1 => TryGetValueOrEmpty(KeyCtrl1);

        protected override T WithMapping<T>() where T : class
        {
            DescriptionToUuid[KeyCtrl1] = Guid.Parse("99FA0031-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}