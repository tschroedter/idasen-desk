﻿using System;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class ReferenceOutput
        : CharacteristicBase,
          IReferenceOutput
    {
        private const string KeyHeightSpeed = "Height Speed";
        private const string KeyTwo         = "TWO";
        private const string KeyThree       = "THREE";
        private const string KeyFour        = "FOUR";
        private const string KeyFive        = "FIVE";
        private const string KeySix         = "SIX";
        private const string KeySeven       = "SEVEN";
        private const string KeyEight       = "EIGHT";
        private const string KeyMask        = "MASK";
        private const string KeyDetectMask  = "DETECT MASK";

        public ReferenceOutput(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider)
            : base(logger,
                   gattDeviceService,
                   customGattCharacteristicProvider)
        {
        }

        public byte[] RawHeightSpeed => TryGetValueOrEmpty(KeyHeightSpeed);
        public byte[] RawTwo         => TryGetValueOrEmpty(KeyTwo);
        public byte[] RawThree       => TryGetValueOrEmpty(KeyThree);
        public byte[] RawFour        => TryGetValueOrEmpty(KeyFour);
        public byte[] RawFive        => TryGetValueOrEmpty(KeyFive);
        public byte[] RawSix         => TryGetValueOrEmpty(KeySix);
        public byte[] RawSeven       => TryGetValueOrEmpty(KeySeven);
        public byte[] RawEight       => TryGetValueOrEmpty(KeyEight);
        public byte[] RawMask        => TryGetValueOrEmpty(KeyMask);
        public byte[] RawDetectMask  => TryGetValueOrEmpty(KeyDetectMask);

        public override T Initialize<T>() where T : class
        {
            DescriptionToUuid[KeyHeightSpeed] = Guid.Parse("99FA0021-338A-1024-8A49-009C0215F78A");
            DescriptionToUuid[KeyMask]        = Guid.Parse("99FA0029-338A-1024-8A49-009C0215F78A");
            DescriptionToUuid[KeyDetectMask]  = Guid.Parse("99FA002A-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}