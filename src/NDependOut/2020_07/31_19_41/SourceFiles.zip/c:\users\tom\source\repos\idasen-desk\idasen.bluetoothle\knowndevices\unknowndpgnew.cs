﻿using Idasen.BluetoothLE.KnownDevices.Characteristics.New;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class UnknownDpgNew
        : Unknown, IDpgNew
    {
        public byte[] RawDpg { get; } = RawArrayEmpty;
    }
}