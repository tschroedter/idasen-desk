﻿using System;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics.New
{
    public class DpgNew
        : CharacteristicBaseNew,
          IDpgNew
    {
        private const string KeyDpg = "Dpg";

        public override Guid GattServiceUuid { get; } = Guid.Parse("99FA0010-338A-1024-8A49-009C0215F78A");

        public delegate IDpgNew Factory(IDevice device);

        public DpgNew(
            ILogger                                   logger,
            IDevice                                   device,
            ICustomGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
        }


        public byte[] RawDpg => TryGetValueOrEmpty(KeyDpg);

        protected override T WithMapping<T>() where T : class
        {
            DescriptionToUuid[KeyDpg] = Guid.Parse("99FA0011-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}