﻿using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class GenericAttribute
        : CharacteristicBase,
          IGenericAttribute
    {
        private readonly IAllGattCharacteristicsProvider _allGattCharacteristicsProvider;

        public const string CharacteristicServiceChanged = "Service Changed";

        public GenericAttribute(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider,
            IAllGattCharacteristicsProvider allGattCharacteristicsProvider)
            : base(logger,
                   gattDeviceService,
                   customGattCharacteristicProvider)
        {
            _allGattCharacteristicsProvider = allGattCharacteristicsProvider;
        }

        public byte[] RawServiceChanged => TryGetValueOrEmpty(CharacteristicServiceChanged);

        public override T Initialize<T>() where T : class
        {
            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicServiceChanged,
                                                          out var uuid))
                DescriptionToUuid[CharacteristicServiceChanged] = uuid;

            return this as T;
        }
    }
}