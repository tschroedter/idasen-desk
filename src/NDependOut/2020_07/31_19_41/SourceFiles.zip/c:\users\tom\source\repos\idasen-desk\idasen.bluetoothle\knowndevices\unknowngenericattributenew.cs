﻿using Idasen.BluetoothLE.KnownDevices.Characteristics;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class UnknownGenericAttributeNew
        : Unknown, IGenericAttributeNew
    {
        public byte[] RawServiceChanged { get; } = RawArrayEmpty;
    }
}