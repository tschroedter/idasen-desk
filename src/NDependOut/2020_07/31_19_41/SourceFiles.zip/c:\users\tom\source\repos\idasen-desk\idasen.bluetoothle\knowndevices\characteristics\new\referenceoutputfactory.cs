﻿using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.KnownDevices.Characteristics.New;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class ReferenceOutputFactory // todo generic factory
        : IReferenceOutputFactory
    {
        private readonly ReferenceOutputNew.Factory _factory;

        public ReferenceOutputFactory([NotNull] ReferenceOutputNew.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }
        public IReferenceOutputNew Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}