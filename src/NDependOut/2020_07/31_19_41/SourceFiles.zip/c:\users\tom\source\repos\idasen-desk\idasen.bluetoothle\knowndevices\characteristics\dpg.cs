﻿using System;
using System.Text;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class Dpg
        : CharacteristicBase,
          IDpg
    {
        private const string KeyDpg = "Dpg";

        public Dpg(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider)
            : base(logger,
                   gattDeviceService,
                   customGattCharacteristicProvider)
        {
        }

        public byte[] RawDpg => TryGetValueOrEmpty(KeyDpg);

        public override T Initialize<T>() where T : class
        {
            DescriptionToUuid[KeyDpg] = Guid.Parse("99FA0011-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}