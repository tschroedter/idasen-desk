﻿using System;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class ReferenceInput
        : CharacteristicBase,
          IReferenceIntput
    {
        private const string KeyCtrl1 = "Ctrl1";
        private const string KeyCtrl2 = "Ctrl2";
        private const string KeyCtrl3 = "Ctrl3";
        private const string KeyCtrl4 = "Ctrl4";

        public ReferenceInput(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider)
            : base(logger,
                   gattDeviceService,
                   customGattCharacteristicProvider)
        {
        }

        public byte[] Ctrl1 => TryGetValueOrEmpty(KeyCtrl1);

        public override T Initialize<T>() where T : class
        {
            DescriptionToUuid[KeyCtrl1] = Guid.Parse("99FA0031-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}