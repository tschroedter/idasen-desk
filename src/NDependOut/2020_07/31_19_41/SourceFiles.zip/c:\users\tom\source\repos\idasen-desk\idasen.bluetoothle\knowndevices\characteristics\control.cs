﻿using System;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage.Streams;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class Control
        : CharacteristicBase,
          IControl
    {
        private const string KeyControl2 = "Ctrl2";
        private const string KeyControl3 = "Ctrl3";

        public Control(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider)
            : base(logger,
                   gattDeviceService,
                   customGattCharacteristicProvider)
        {
        }

        public byte[] RawControl2 => TryGetValueOrEmpty(KeyControl2);
        public byte[] RawControl3 => TryGetValueOrEmpty(KeyControl3);

        public override T Initialize<T>() where T : class
        {
            //DescriptionToUuid[KeyControl] = Guid.Parse("99FA0011-338A-1024-8A49-009C0215F78A");

            DescriptionToUuid[KeyControl2] = Guid.Parse("99fa0002-338a-1024-8a49-009c0215f78a");
            DescriptionToUuid[KeyControl3] = Guid.Parse("99fa0003-338a-1024-8a49-009c0215f78a");

            return this as T;
        }

        public async Task<bool> TryWriteRawControl2(byte[] bytes)
        {
            return await TryWriteValueAsync(KeyControl2, bytes);
        }
    }
}