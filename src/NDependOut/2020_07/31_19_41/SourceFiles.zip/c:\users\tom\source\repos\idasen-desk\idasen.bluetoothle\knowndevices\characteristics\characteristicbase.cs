﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public abstract class CharacteristicBase
        : ICharacteristic
    {
        protected static readonly byte[] RawArrayEmpty = Enumerable.Empty<byte>()
                                                                   .ToArray();

        private static readonly byte[] ArrayEmpty = Enumerable.Empty<byte>()
                                                              .ToArray();

        private static readonly (bool, byte[]) Failed = (false, ArrayEmpty);

        protected readonly Dictionary<string, Guid> DescriptionToUuid =
            new Dictionary<string, Guid>();

        protected readonly Dictionary<string, Guid> DescriptionToUuidAvailable =
            new Dictionary<string, Guid>();

        protected readonly IGattCharacteristicsResultWrapper GattCharacteristics;
        protected readonly IGattDeviceServiceWrapper         GattDeviceService;
        protected readonly ICustomGattCharacteristicProvider CustomGattCharacteristicProvider;
        protected readonly ILogger                           Logger;

        protected readonly Dictionary<string, byte[]> RawValues = new Dictionary<string, byte[]>();

        protected CharacteristicBase(
            ILogger                           logger,
            IGattDeviceServiceWrapper         gattDeviceService,
            ICustomGattCharacteristicProvider customGattCharacteristicProvider)
        {
            Logger                           = logger;
            GattDeviceService                = gattDeviceService;
            CustomGattCharacteristicProvider = customGattCharacteristicProvider;
        }

        public byte?                   ProtocolError { get; private set; }
        public GattCommunicationStatus Status        { get; private set; }

        [UsedImplicitly]
        public abstract T Initialize<T>() where T : class;

        public virtual async Task Refresh()
        {
            CustomGattCharacteristicProvider.Refresh(DescriptionToUuid);

            foreach (var keyValuePair in CustomGattCharacteristicProvider.Characteristics)
            {
                (bool success, byte[] value) result =
                    await TryGetReadValueAsync(keyValuePair.Value);

                RawValues[keyValuePair.Key] = result.success
                                                  ? result.value
                                                  : RawArrayEmpty;
            }
        }

        public async Task<(bool, byte[])> TryGetReadValueAsync(Guid uuid)
        {
            var characteristic = GattCharacteristics.Characteristics
                                                    .FirstOrDefault(x => x.Uuid == uuid);

            if (characteristic != null)
                return await TryGetReadValueAsync(characteristic);

            Logger.Error($"Unknown characteristic UUID '{uuid}'");

            foreach (var available in GattCharacteristics.Characteristics)
            {
                Logger.Information($"GattDeviceService {GattDeviceService.Uuid} - Characteristics Characteristics {available.Uuid}");
            }

            return Failed;

        }

        public async Task<(bool, byte[])> TryGetReadValueAsync(GattCharacteristic characteristic)
        {
            if ((characteristic.CharacteristicProperties & GattCharacteristicProperties.Read) !=
                GattCharacteristicProperties.Read)
            {
                Log.Information($"GattCharacteristic '{characteristic.Uuid}' doesn't support 'Read'");

                return (false, ArrayEmpty);
            }

            var readValue = await characteristic.ReadValueAsync();

            ProtocolError = readValue.ProtocolError;
            Status        = readValue.Status;

            var success = GattCommunicationStatus.Success == Status;

            if (GattCommunicationStatus.Success != Status)
                return (false, ArrayEmpty);

            var reader = DataReader.FromBuffer(readValue.Value);
            var bytes  = new byte[reader.UnconsumedBufferLength];
            reader.ReadBytes(bytes);

            return (success, bytes);
        }

        public async Task<bool> TryWriteValueAsync(
            GattCharacteristic characteristic,
            IBuffer            buffer)
        {
            if ((characteristic.CharacteristicProperties & GattCharacteristicProperties.Write) !=
                GattCharacteristicProperties.Write &&
                (characteristic.CharacteristicProperties & GattCharacteristicProperties.WritableAuxiliaries) !=
                GattCharacteristicProperties.WritableAuxiliaries &&
                (characteristic.CharacteristicProperties & GattCharacteristicProperties.WriteWithoutResponse) !=
                GattCharacteristicProperties.WriteWithoutResponse)
            {
                Log.Information($"GattCharacteristic '{characteristic.Uuid}' doesn't support 'Write/WritableAuxiliaries/WriteWithoutResponse'");

                return false;
            }

            var status = await characteristic.WriteValueAsync(buffer);

            return status == GattCommunicationStatus.Success;

        }


        // todo add to ToString
        public async Task<IReadOnlyList<GattDescriptor>> TryGetDescriptorsAsync(Guid uuid)
        {
            var characteristic = GattCharacteristics.Characteristics
                                                    .FirstOrDefault(x => x.Uuid == uuid);

            if (characteristic == null)
            {
                Logger.Error($"Unknown characteristic UUID '{uuid}'");

                return new List<GattDescriptor>();
            }

            var test = await characteristic.GetDescriptorsAsync();

            if (test.Status != GattCommunicationStatus.Success)
            {
                return new List<GattDescriptor>();
            }

            foreach (GattDescriptor descriptor in test.Descriptors)
            {
                var result = await descriptor.ReadValueAsync();

                if (result.Status != GattCommunicationStatus.Success)
                {
                    Logger.Error($"Failed for GattDescriptor {descriptor.Uuid}");

                    continue;
                }

                Logger.Information($"Descriptor UUID {descriptor.Uuid} "            +
                                   $"AttributeHandle {descriptor.AttributeHandle} " +
                                   $"ProtectionLevel {descriptor.ProtectionLevel} " +
                                   $"Status {result.Status}");

                var descriptorValue = await descriptor.ReadValueAsync();

                if (descriptorValue.Status != GattCommunicationStatus.Success)
                {
                    Logger.Error($"Failed for GattDescriptor {descriptor.Uuid} value");

                    continue;
                }

                Logger.Information($"{descriptorValue.Value.ToArray().ToHex()}");
            }

            return test.Descriptors;

        }

        protected async Task<bool> TryWriteValueAsync(string key,
                                                      byte[] bytes)
        {
            var characteristic = CustomGattCharacteristicProvider.Characteristics[key];

            if (characteristic == null)
            {
                // todo log error
                return false;
            }

            return await TryWriteValueAsync(characteristic, bytes.AsBuffer());
        }

        protected byte[] TryGetValueOrEmpty(string key)
        {
            return RawValues.TryGetValue(key,
                                         out var values)
                       ? values
                       : RawArrayEmpty;
        }

        protected string RawValueOrUnavailable(string key,
                                               byte[] value)
        {
            return CustomGattCharacteristicProvider.Characteristics
                                                   .ContainsKey(key)
                       ? $"{key} = [{value.ToHex()}]"
                       : $"{key} = Unavailable";
        }

        protected string PropertiesToString(GattCharacteristicProperties properties) // todo duplicated code
        {
            var list = new List<GattCharacteristicProperties>();

            foreach (GattCharacteristicProperties property in Enum.GetValues(typeof(GattCharacteristicProperties)))
            {
                if ((properties & property) == property)
                {
                    list.Add(property);
                }
            }

            return string.Join(", ", list);
        }

        public override string ToString()
        {
            var builder = new StringBuilder();

            builder.AppendLine($"{GetType().Name}");

            foreach (var key in DescriptionToUuid.Keys)
            {
                var rawValueOrUnavailable = RawValueOrUnavailable(key,
                                                                  TryGetValueOrEmpty(key));

                builder.Append(rawValueOrUnavailable);

                if (CustomGattCharacteristicProvider.Properties.TryGetValue(key,
                                                                            out GattCharacteristicProperties properties)
                )
                {
                    builder.AppendLine($" ({PropertiesToString(properties)})");
                }
                else
                {
                    builder.AppendLine();
                }

            }

            return builder.ToString();
        }
    }

    public interface ICharacteristic
    {
    }
}