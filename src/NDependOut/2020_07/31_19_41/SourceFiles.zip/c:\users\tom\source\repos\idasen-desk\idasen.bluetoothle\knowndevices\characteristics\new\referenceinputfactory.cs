﻿using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.KnownDevices.Characteristics.New;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class ReferenceInputFactory // todo generic factory
        : IReferenceInputFactory
    {
        private readonly ReferenceInputNew.Factory _factory;

        public ReferenceInputFactory([NotNull] ReferenceInputNew.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }
        public IReferenceInputNew Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}