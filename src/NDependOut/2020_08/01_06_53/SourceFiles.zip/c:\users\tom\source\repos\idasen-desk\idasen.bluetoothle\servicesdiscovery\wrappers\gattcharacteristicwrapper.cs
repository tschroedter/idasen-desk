﻿using System.Diagnostics.CodeAnalysis;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using NotNullAttribute = JetBrains.Annotations.NotNullAttribute;

namespace Idasen.BluetoothLE.ServicesDiscovery.Wrappers
{
    /// <inheritdoc />
    [ExcludeFromCodeCoverage]
    public class GattCharacteristicWrapper
        : IGattCharacteristicWrapper
    {
        private readonly GattCharacteristic _gattCharacteristic;    // todo use it

        public GattCharacteristicWrapper(
            [NotNull] GattCharacteristic gattCharacteristic)
        {
            Guard.ArgumentNotNull(gattCharacteristic,
                                  nameof(gattCharacteristic));

            _gattCharacteristic = gattCharacteristic;
        }
    }
}