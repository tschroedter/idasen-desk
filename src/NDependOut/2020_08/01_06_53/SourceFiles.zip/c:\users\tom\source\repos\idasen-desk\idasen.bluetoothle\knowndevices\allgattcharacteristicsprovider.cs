﻿using System;
using System.Collections.Generic;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class AllGattCharacteristicsProvider
    : IAllGattCharacteristicsProvider
    {
        private readonly Dictionary<Guid, string> _uuidToDescription = new Dictionary<Guid, string>();
        private readonly Dictionary<string, Guid> _descriptionToUuid = new Dictionary<string, Guid>();

        public AllGattCharacteristicsProvider()
        {
            _uuidToDescription[Guid.Parse("00002a00-0000-1000-8000-00805f9b34fb")] = "Device Name";
            _uuidToDescription[Guid.Parse("00002a01-0000-1000-8000-00805f9b34fb")] = "Appearance";
            _uuidToDescription[Guid.Parse("00002a02-0000-1000-8000-00805f9b34fb")] = "Peripheral Privacy Flag";
            _uuidToDescription[Guid.Parse("00002a03-0000-1000-8000-00805f9b34fb")] = "Reconnection Address";
            _uuidToDescription[Guid.Parse("00002a04-0000-1000-8000-00805f9b34fb")] = "Peripheral Preferred Connection Parameters";
            _uuidToDescription[Guid.Parse("00002a05-0000-1000-8000-00805f9b34fb")] = "Service Changed";
            _uuidToDescription[Guid.Parse("00002a06-0000-1000-8000-00805f9b34fb")] = "Alert Level";
            _uuidToDescription[Guid.Parse("00002a07-0000-1000-8000-00805f9b34fb")] = "Tx Power Level";
            _uuidToDescription[Guid.Parse("00002a08-0000-1000-8000-00805f9b34fb")] = "Date Time";
            _uuidToDescription[Guid.Parse("00002a09-0000-1000-8000-00805f9b34fb")] = "Day of Week";
            _uuidToDescription[Guid.Parse("00002a0a-0000-1000-8000-00805f9b34fb")] = "Day Date Time";
            _uuidToDescription[Guid.Parse("00002a0b-0000-1000-8000-00805f9b34fb")] = "Exact Time 100";
            _uuidToDescription[Guid.Parse("00002a0c-0000-1000-8000-00805f9b34fb")] = "Exact Time 256";
            _uuidToDescription[Guid.Parse("00002a0d-0000-1000-8000-00805f9b34fb")] = "DST Offset";
            _uuidToDescription[Guid.Parse("00002a0e-0000-1000-8000-00805f9b34fb")] = "Time Zone";
            _uuidToDescription[Guid.Parse("00002a0f-0000-1000-8000-00805f9b34fb")] = "Local Time Information";
            _uuidToDescription[Guid.Parse("00002a10-0000-1000-8000-00805f9b34fb")] = "Secondary Time Zone";
            _uuidToDescription[Guid.Parse("00002a11-0000-1000-8000-00805f9b34fb")] = "Time with DST";
            _uuidToDescription[Guid.Parse("00002a12-0000-1000-8000-00805f9b34fb")] = "Time Accuracy";
            _uuidToDescription[Guid.Parse("00002a13-0000-1000-8000-00805f9b34fb")] = "Time Source";
            _uuidToDescription[Guid.Parse("00002a14-0000-1000-8000-00805f9b34fb")] = "Reference Time Information";
            _uuidToDescription[Guid.Parse("00002a15-0000-1000-8000-00805f9b34fb")] = "Time Broadcast";
            _uuidToDescription[Guid.Parse("00002a16-0000-1000-8000-00805f9b34fb")] = "Time Update Control Point";
            _uuidToDescription[Guid.Parse("00002a17-0000-1000-8000-00805f9b34fb")] = "Time Update State";
            _uuidToDescription[Guid.Parse("00002a18-0000-1000-8000-00805f9b34fb")] = "Glucose Measurement";
            _uuidToDescription[Guid.Parse("00002a19-0000-1000-8000-00805f9b34fb")] = "Battery Level";
            _uuidToDescription[Guid.Parse("00002a1a-0000-1000-8000-00805f9b34fb")] = "Battery Power State";
            _uuidToDescription[Guid.Parse("00002a1b-0000-1000-8000-00805f9b34fb")] = "Battery Level State";
            _uuidToDescription[Guid.Parse("00002a1c-0000-1000-8000-00805f9b34fb")] = "Temperature Measurement";
            _uuidToDescription[Guid.Parse("00002a1d-0000-1000-8000-00805f9b34fb")] = "Temperature Type";
            _uuidToDescription[Guid.Parse("00002a1e-0000-1000-8000-00805f9b34fb")] = "Intermediate Temperature";
            _uuidToDescription[Guid.Parse("00002a1f-0000-1000-8000-00805f9b34fb")] = "Temperature Celsius";
            _uuidToDescription[Guid.Parse("00002a20-0000-1000-8000-00805f9b34fb")] = "Temperature Fahrenheit";
            _uuidToDescription[Guid.Parse("00002a21-0000-1000-8000-00805f9b34fb")] = "Measurement Interval";
            _uuidToDescription[Guid.Parse("00002a22-0000-1000-8000-00805f9b34fb")] = "Boot Keyboard Input Report";
            _uuidToDescription[Guid.Parse("00002a23-0000-1000-8000-00805f9b34fb")] = "System ID";
            _uuidToDescription[Guid.Parse("00002a24-0000-1000-8000-00805f9b34fb")] = "Model Number String";
            _uuidToDescription[Guid.Parse("00002a25-0000-1000-8000-00805f9b34fb")] = "Serial Number String";
            _uuidToDescription[Guid.Parse("00002a26-0000-1000-8000-00805f9b34fb")] = "Firmware Revision String";
            _uuidToDescription[Guid.Parse("00002a27-0000-1000-8000-00805f9b34fb")] = "Hardware Revision String";
            _uuidToDescription[Guid.Parse("00002a28-0000-1000-8000-00805f9b34fb")] = "Software Revision String";
            _uuidToDescription[Guid.Parse("00002a29-0000-1000-8000-00805f9b34fb")] = "Manufacturer Name String";
            _uuidToDescription[Guid.Parse("00002a2a-0000-1000-8000-00805f9b34fb")] = "IEEE 11073-20601 Regulatory Certification Data List";
            _uuidToDescription[Guid.Parse("00002a2b-0000-1000-8000-00805f9b34fb")] = "Current Time";
            _uuidToDescription[Guid.Parse("00002a2c-0000-1000-8000-00805f9b34fb")] = "Magnetic Declination";
            _uuidToDescription[Guid.Parse("00002a2f-0000-1000-8000-00805f9b34fb")] = "Position 2D";
            _uuidToDescription[Guid.Parse("00002a30-0000-1000-8000-00805f9b34fb")] = "Position 3D";
            _uuidToDescription[Guid.Parse("00002a31-0000-1000-8000-00805f9b34fb")] = "Scan Refresh";
            _uuidToDescription[Guid.Parse("00002a32-0000-1000-8000-00805f9b34fb")] = "Boot Keyboard Output Report";
            _uuidToDescription[Guid.Parse("00002a33-0000-1000-8000-00805f9b34fb")] = "Boot Mouse Input Report";
            _uuidToDescription[Guid.Parse("00002a34-0000-1000-8000-00805f9b34fb")] = "Glucose Measurement Context";
            _uuidToDescription[Guid.Parse("00002a35-0000-1000-8000-00805f9b34fb")] = "Blood Pressure Measurement";
            _uuidToDescription[Guid.Parse("00002a36-0000-1000-8000-00805f9b34fb")] = "Intermediate Cuff Pressure";
            _uuidToDescription[Guid.Parse("00002a37-0000-1000-8000-00805f9b34fb")] = "Heart Rate Measurement";
            _uuidToDescription[Guid.Parse("00002a38-0000-1000-8000-00805f9b34fb")] = "Body Sensor Location";
            _uuidToDescription[Guid.Parse("00002a39-0000-1000-8000-00805f9b34fb")] = "Heart Rate Control Point";
            _uuidToDescription[Guid.Parse("00002a3a-0000-1000-8000-00805f9b34fb")] = "Removable";
            _uuidToDescription[Guid.Parse("00002a3b-0000-1000-8000-00805f9b34fb")] = "Service Required";
            _uuidToDescription[Guid.Parse("00002a3c-0000-1000-8000-00805f9b34fb")] = "Scientific Temperature Celsius";
            _uuidToDescription[Guid.Parse("00002a3d-0000-1000-8000-00805f9b34fb")] = "String";
            _uuidToDescription[Guid.Parse("00002a3e-0000-1000-8000-00805f9b34fb")] = "Network Availability";
            _uuidToDescription[Guid.Parse("00002a3f-0000-1000-8000-00805f9b34fb")] = "Alert Status";
            _uuidToDescription[Guid.Parse("00002a40-0000-1000-8000-00805f9b34fb")] = "Ringer Control point";
            _uuidToDescription[Guid.Parse("00002a41-0000-1000-8000-00805f9b34fb")] = "Ringer Setting";
            _uuidToDescription[Guid.Parse("00002a42-0000-1000-8000-00805f9b34fb")] = "Alert Category ID Bit Mask";
            _uuidToDescription[Guid.Parse("00002a43-0000-1000-8000-00805f9b34fb")] = "Alert Category ID";
            _uuidToDescription[Guid.Parse("00002a44-0000-1000-8000-00805f9b34fb")] = "Alert Notification Control Point";
            _uuidToDescription[Guid.Parse("00002a45-0000-1000-8000-00805f9b34fb")] = "Unread Alert Status";
            _uuidToDescription[Guid.Parse("00002a46-0000-1000-8000-00805f9b34fb")] = "New Alert";
            _uuidToDescription[Guid.Parse("00002a47-0000-1000-8000-00805f9b34fb")] = "Supported New Alert Category";
            _uuidToDescription[Guid.Parse("00002a48-0000-1000-8000-00805f9b34fb")] = "Supported Unread Alert Category";
            _uuidToDescription[Guid.Parse("00002a49-0000-1000-8000-00805f9b34fb")] = "Blood Pressure Feature";
            _uuidToDescription[Guid.Parse("00002a4a-0000-1000-8000-00805f9b34fb")] = "HID Information";
            _uuidToDescription[Guid.Parse("00002a4b-0000-1000-8000-00805f9b34fb")] = "Report Map";
            _uuidToDescription[Guid.Parse("00002a4c-0000-1000-8000-00805f9b34fb")] = "HID Control Point";
            _uuidToDescription[Guid.Parse("00002a4d-0000-1000-8000-00805f9b34fb")] = "Report";
            _uuidToDescription[Guid.Parse("00002a4e-0000-1000-8000-00805f9b34fb")] = "Protocol Mode";
            _uuidToDescription[Guid.Parse("00002a4f-0000-1000-8000-00805f9b34fb")] = "Scan Interval Window";
            _uuidToDescription[Guid.Parse("00002a50-0000-1000-8000-00805f9b34fb")] = "PnP ID";
            _uuidToDescription[Guid.Parse("00002a51-0000-1000-8000-00805f9b34fb")] = "Glucose Feature";
            _uuidToDescription[Guid.Parse("00002a52-0000-1000-8000-00805f9b34fb")] = "Record Access Control Point";
            _uuidToDescription[Guid.Parse("00002a53-0000-1000-8000-00805f9b34fb")] = "RSC Measurement";
            _uuidToDescription[Guid.Parse("00002a54-0000-1000-8000-00805f9b34fb")] = "RSC Feature";
            _uuidToDescription[Guid.Parse("00002a55-0000-1000-8000-00805f9b34fb")] = "SC Control Point";
            _uuidToDescription[Guid.Parse("00002a56-0000-1000-8000-00805f9b34fb")] = "Digital";
            _uuidToDescription[Guid.Parse("00002a57-0000-1000-8000-00805f9b34fb")] = "Digital Output";
            _uuidToDescription[Guid.Parse("00002a58-0000-1000-8000-00805f9b34fb")] = "Analog";
            _uuidToDescription[Guid.Parse("00002a59-0000-1000-8000-00805f9b34fb")] = "Analog Output";
            _uuidToDescription[Guid.Parse("00002a5a-0000-1000-8000-00805f9b34fb")] = "Aggregate";
            _uuidToDescription[Guid.Parse("00002a5b-0000-1000-8000-00805f9b34fb")] = "CSC Measurement";
            _uuidToDescription[Guid.Parse("00002a5c-0000-1000-8000-00805f9b34fb")] = "CSC Feature";
            _uuidToDescription[Guid.Parse("00002a5d-0000-1000-8000-00805f9b34fb")] = "Sensor Location";
            _uuidToDescription[Guid.Parse("00002a5e-0000-1000-8000-00805f9b34fb")] = "PLX Spot-Check Measurement";
            _uuidToDescription[Guid.Parse("00002a5f-0000-1000-8000-00805f9b34fb")] = "PLX Continuous Measurement Characteristic";
            _uuidToDescription[Guid.Parse("00002a60-0000-1000-8000-00805f9b34fb")] = "PLX Features";
            _uuidToDescription[Guid.Parse("00002a62-0000-1000-8000-00805f9b34fb")] = "Pulse Oximetry Control Point";
            _uuidToDescription[Guid.Parse("00002a63-0000-1000-8000-00805f9b34fb")] = "Cycling Power Measurement";
            _uuidToDescription[Guid.Parse("00002a64-0000-1000-8000-00805f9b34fb")] = "Cycling Power Vector";
            _uuidToDescription[Guid.Parse("00002a65-0000-1000-8000-00805f9b34fb")] = "Cycling Power Feature";
            _uuidToDescription[Guid.Parse("00002a66-0000-1000-8000-00805f9b34fb")] = "Cycling Power Control Point";
            _uuidToDescription[Guid.Parse("00002a67-0000-1000-8000-00805f9b34fb")] = "Location and Speed Characteristic";
            _uuidToDescription[Guid.Parse("00002a68-0000-1000-8000-00805f9b34fb")] = "Navigation";
            _uuidToDescription[Guid.Parse("00002a69-0000-1000-8000-00805f9b34fb")] = "Position Quality";
            _uuidToDescription[Guid.Parse("00002a6a-0000-1000-8000-00805f9b34fb")] = "LN Feature";
            _uuidToDescription[Guid.Parse("00002a6b-0000-1000-8000-00805f9b34fb")] = "LN Control Point";
            _uuidToDescription[Guid.Parse("00002a6c-0000-1000-8000-00805f9b34fb")] = "Elevation";
            _uuidToDescription[Guid.Parse("00002a6d-0000-1000-8000-00805f9b34fb")] = "Pressure";
            _uuidToDescription[Guid.Parse("00002a6e-0000-1000-8000-00805f9b34fb")] = "Temperature";
            _uuidToDescription[Guid.Parse("00002a6f-0000-1000-8000-00805f9b34fb")] = "Humidity";
            _uuidToDescription[Guid.Parse("00002a70-0000-1000-8000-00805f9b34fb")] = "True Wind Speed";
            _uuidToDescription[Guid.Parse("00002a71-0000-1000-8000-00805f9b34fb")] = "True Wind Direction";
            _uuidToDescription[Guid.Parse("00002a72-0000-1000-8000-00805f9b34fb")] = "Apparent Wind Speed";
            _uuidToDescription[Guid.Parse("00002a73-0000-1000-8000-00805f9b34fb")] = "Apparent Wind Direction";
            _uuidToDescription[Guid.Parse("00002a74-0000-1000-8000-00805f9b34fb")] = "Gust Factor";
            _uuidToDescription[Guid.Parse("00002a75-0000-1000-8000-00805f9b34fb")] = "Pollen Concentration";
            _uuidToDescription[Guid.Parse("00002a76-0000-1000-8000-00805f9b34fb")] = "UV Index";
            _uuidToDescription[Guid.Parse("00002a77-0000-1000-8000-00805f9b34fb")] = "Irradiance";
            _uuidToDescription[Guid.Parse("00002a78-0000-1000-8000-00805f9b34fb")] = "Rainfall";
            _uuidToDescription[Guid.Parse("00002a79-0000-1000-8000-00805f9b34fb")] = "Wind Chill";
            _uuidToDescription[Guid.Parse("00002a7a-0000-1000-8000-00805f9b34fb")] = "Heat Index";
            _uuidToDescription[Guid.Parse("00002a7b-0000-1000-8000-00805f9b34fb")] = "Dew Point";
            _uuidToDescription[Guid.Parse("00002a7d-0000-1000-8000-00805f9b34fb")] = "Descriptor Value Changed";
            _uuidToDescription[Guid.Parse("00002a7e-0000-1000-8000-00805f9b34fb")] = "Aerobic Heart Rate Lower Limit";
            _uuidToDescription[Guid.Parse("00002a7f-0000-1000-8000-00805f9b34fb")] = "Aerobic Threshold";
            _uuidToDescription[Guid.Parse("00002a80-0000-1000-8000-00805f9b34fb")] = "Age";
            _uuidToDescription[Guid.Parse("00002a81-0000-1000-8000-00805f9b34fb")] = "Anaerobic Heart Rate Lower Limit";
            _uuidToDescription[Guid.Parse("00002a82-0000-1000-8000-00805f9b34fb")] = "Anaerobic Heart Rate Upper Limit";
            _uuidToDescription[Guid.Parse("00002a83-0000-1000-8000-00805f9b34fb")] = "Anaerobic Threshold";
            _uuidToDescription[Guid.Parse("00002a84-0000-1000-8000-00805f9b34fb")] = "Aerobic Heart Rate Upper Limit";
            _uuidToDescription[Guid.Parse("00002a85-0000-1000-8000-00805f9b34fb")] = "Date of Birth";
            _uuidToDescription[Guid.Parse("00002a86-0000-1000-8000-00805f9b34fb")] = "Date of Threshold Assessment";
            _uuidToDescription[Guid.Parse("00002a87-0000-1000-8000-00805f9b34fb")] = "Email Address";
            _uuidToDescription[Guid.Parse("00002a88-0000-1000-8000-00805f9b34fb")] = "Fat Burn Heart Rate Lower Limit";
            _uuidToDescription[Guid.Parse("00002a89-0000-1000-8000-00805f9b34fb")] = "Fat Burn Heart Rate Upper Limit";
            _uuidToDescription[Guid.Parse("00002a8a-0000-1000-8000-00805f9b34fb")] = "First Name";
            _uuidToDescription[Guid.Parse("00002a8b-0000-1000-8000-00805f9b34fb")] = "Five Zone Heart Rate Limits";
            _uuidToDescription[Guid.Parse("00002a8c-0000-1000-8000-00805f9b34fb")] = "Gender";
            _uuidToDescription[Guid.Parse("00002a8d-0000-1000-8000-00805f9b34fb")] = "Heart Rate Max";
            _uuidToDescription[Guid.Parse("00002a8e-0000-1000-8000-00805f9b34fb")] = "Height";
            _uuidToDescription[Guid.Parse("00002a8f-0000-1000-8000-00805f9b34fb")] = "Hip Circumference";
            _uuidToDescription[Guid.Parse("00002a90-0000-1000-8000-00805f9b34fb")] = "Last Name";
            _uuidToDescription[Guid.Parse("00002a91-0000-1000-8000-00805f9b34fb")] = "Maximum Recommended Heart Rate";
            _uuidToDescription[Guid.Parse("00002a92-0000-1000-8000-00805f9b34fb")] = "Resting Heart Rate";
            _uuidToDescription[Guid.Parse("00002a93-0000-1000-8000-00805f9b34fb")] = "Sport Type for Aerobic and Anaerobic Thresholds";
            _uuidToDescription[Guid.Parse("00002a94-0000-1000-8000-00805f9b34fb")] = "Three Zone Heart Rate Limits";
            _uuidToDescription[Guid.Parse("00002a95-0000-1000-8000-00805f9b34fb")] = "Two Zone Heart Rate Limit";
            _uuidToDescription[Guid.Parse("00002a96-0000-1000-8000-00805f9b34fb")] = "VO2 Max";
            _uuidToDescription[Guid.Parse("00002a97-0000-1000-8000-00805f9b34fb")] = "Waist Circumference";
            _uuidToDescription[Guid.Parse("00002a98-0000-1000-8000-00805f9b34fb")] = "Weight";
            _uuidToDescription[Guid.Parse("00002a99-0000-1000-8000-00805f9b34fb")] = "Database Change Increment";
            _uuidToDescription[Guid.Parse("00002a9a-0000-1000-8000-00805f9b34fb")] = "User Index";
            _uuidToDescription[Guid.Parse("00002a9b-0000-1000-8000-00805f9b34fb")] = "Body Composition Feature";
            _uuidToDescription[Guid.Parse("00002a9c-0000-1000-8000-00805f9b34fb")] = "Body Composition Measurement";
            _uuidToDescription[Guid.Parse("00002a9d-0000-1000-8000-00805f9b34fb")] = "Weight Measurement";
            _uuidToDescription[Guid.Parse("00002a9e-0000-1000-8000-00805f9b34fb")] = "Weight Scale Feature";
            _uuidToDescription[Guid.Parse("00002a9f-0000-1000-8000-00805f9b34fb")] = "User Control Point";
            _uuidToDescription[Guid.Parse("00002aa0-0000-1000-8000-00805f9b34fb")] = "Magnetic Flux Density - 2D";
            _uuidToDescription[Guid.Parse("00002aa1-0000-1000-8000-00805f9b34fb")] = "Magnetic Flux Density - 3D";
            _uuidToDescription[Guid.Parse("00002aa2-0000-1000-8000-00805f9b34fb")] = "Language";
            _uuidToDescription[Guid.Parse("00002aa3-0000-1000-8000-00805f9b34fb")] = "Barometric Pressure Trend";
            _uuidToDescription[Guid.Parse("00002aa4-0000-1000-8000-00805f9b34fb")] = "Bond Management Control Point";
            _uuidToDescription[Guid.Parse("00002aa5-0000-1000-8000-00805f9b34fb")] = "Bond Management Features";
            _uuidToDescription[Guid.Parse("00002aa6-0000-1000-8000-00805f9b34fb")] = "Central Address Resolution";
            _uuidToDescription[Guid.Parse("00002aa7-0000-1000-8000-00805f9b34fb")] = "CGM Measurement";
            _uuidToDescription[Guid.Parse("00002aa8-0000-1000-8000-00805f9b34fb")] = "CGM Feature";
            _uuidToDescription[Guid.Parse("00002aa9-0000-1000-8000-00805f9b34fb")] = "CGM Status";
            _uuidToDescription[Guid.Parse("00002aaa-0000-1000-8000-00805f9b34fb")] = "CGM Session Start Time";
            _uuidToDescription[Guid.Parse("00002aab-0000-1000-8000-00805f9b34fb")] = "CGM Session Run Time";
            _uuidToDescription[Guid.Parse("00002aac-0000-1000-8000-00805f9b34fb")] = "CGM Specific Ops Control Point";
            _uuidToDescription[Guid.Parse("00002aad-0000-1000-8000-00805f9b34fb")] = "Indoor Positioning Configuration";
            _uuidToDescription[Guid.Parse("00002aae-0000-1000-8000-00805f9b34fb")] = "Latitude";
            _uuidToDescription[Guid.Parse("00002aaf-0000-1000-8000-00805f9b34fb")] = "Longitude";
            _uuidToDescription[Guid.Parse("00002ab0-0000-1000-8000-00805f9b34fb")] = "Local North Coordinate";
            _uuidToDescription[Guid.Parse("00002ab1-0000-1000-8000-00805f9b34fb")] = "Local East Coordinate";
            _uuidToDescription[Guid.Parse("00002ab2-0000-1000-8000-00805f9b34fb")] = "Floor Number";
            _uuidToDescription[Guid.Parse("00002ab3-0000-1000-8000-00805f9b34fb")] = "Altitude";
            _uuidToDescription[Guid.Parse("00002ab4-0000-1000-8000-00805f9b34fb")] = "Uncertainty";
            _uuidToDescription[Guid.Parse("00002ab5-0000-1000-8000-00805f9b34fb")] = "Location Name";
            _uuidToDescription[Guid.Parse("00002ab6-0000-1000-8000-00805f9b34fb")] = "URI";
            _uuidToDescription[Guid.Parse("00002ab7-0000-1000-8000-00805f9b34fb")] = "HTTP Headers";
            _uuidToDescription[Guid.Parse("00002ab8-0000-1000-8000-00805f9b34fb")] = "HTTP Status Code";
            _uuidToDescription[Guid.Parse("00002ab9-0000-1000-8000-00805f9b34fb")] = "HTTP Entity Body";
            _uuidToDescription[Guid.Parse("00002aba-0000-1000-8000-00805f9b34fb")] = "HTTP Control Point";
            _uuidToDescription[Guid.Parse("00002abb-0000-1000-8000-00805f9b34fb")] = "HTTPS Security";
            _uuidToDescription[Guid.Parse("00002abc-0000-1000-8000-00805f9b34fb")] = "TDS Control Point";
            _uuidToDescription[Guid.Parse("00002abd-0000-1000-8000-00805f9b34fb")] = "OTS Feature";
            _uuidToDescription[Guid.Parse("00002abe-0000-1000-8000-00805f9b34fb")] = "Object Name";
            _uuidToDescription[Guid.Parse("00002abf-0000-1000-8000-00805f9b34fb")] = "Object Type";
            _uuidToDescription[Guid.Parse("00002ac0-0000-1000-8000-00805f9b34fb")] = "Object Size";
            _uuidToDescription[Guid.Parse("00002ac1-0000-1000-8000-00805f9b34fb")] = "Object First-Created";
            _uuidToDescription[Guid.Parse("00002ac2-0000-1000-8000-00805f9b34fb")] = "Object Last-Modified";
            _uuidToDescription[Guid.Parse("00002ac3-0000-1000-8000-00805f9b34fb")] = "Object ID";
            _uuidToDescription[Guid.Parse("00002ac4-0000-1000-8000-00805f9b34fb")] = "Object Characteristics";
            _uuidToDescription[Guid.Parse("00002ac5-0000-1000-8000-00805f9b34fb")] = "Object Action Control Point";
            _uuidToDescription[Guid.Parse("00002ac6-0000-1000-8000-00805f9b34fb")] = "Object List Control Point";
            _uuidToDescription[Guid.Parse("00002ac7-0000-1000-8000-00805f9b34fb")] = "Object List Filter";
            _uuidToDescription[Guid.Parse("00002ac8-0000-1000-8000-00805f9b34fb")] = "Object Changed";
            _uuidToDescription[Guid.Parse("00002ac9-0000-1000-8000-00805f9b34fb")] = "Resolvable Private Address Only";
            _uuidToDescription[Guid.Parse("00002acc-0000-1000-8000-00805f9b34fb")] = "Fitness Machine Feature";
            _uuidToDescription[Guid.Parse("00002acd-0000-1000-8000-00805f9b34fb")] = "Treadmill Data";
            _uuidToDescription[Guid.Parse("00002ace-0000-1000-8000-00805f9b34fb")] = "Cross Trainer Data";
            _uuidToDescription[Guid.Parse("00002acf-0000-1000-8000-00805f9b34fb")] = "Step Climber Data";
            _uuidToDescription[Guid.Parse("00002ad0-0000-1000-8000-00805f9b34fb")] = "Stair Climber Data";
            _uuidToDescription[Guid.Parse("00002ad1-0000-1000-8000-00805f9b34fb")] = "Rower Data";
            _uuidToDescription[Guid.Parse("00002ad2-0000-1000-8000-00805f9b34fb")] = "Indoor Bike Data";
            _uuidToDescription[Guid.Parse("00002ad3-0000-1000-8000-00805f9b34fb")] = "Training Status";
            _uuidToDescription[Guid.Parse("00002ad4-0000-1000-8000-00805f9b34fb")] = "Supported Speed Range";
            _uuidToDescription[Guid.Parse("00002ad5-0000-1000-8000-00805f9b34fb")] = "Supported Inclination Range";
            _uuidToDescription[Guid.Parse("00002ad6-0000-1000-8000-00805f9b34fb")] = "Supported Resistance Level Range";
            _uuidToDescription[Guid.Parse("00002ad7-0000-1000-8000-00805f9b34fb")] = "Supported Heart Rate Range";
            _uuidToDescription[Guid.Parse("00002ad8-0000-1000-8000-00805f9b34fb")] = "Supported Power Range";
            _uuidToDescription[Guid.Parse("00002ad9-0000-1000-8000-00805f9b34fb")] = "Fitness Machine Control Point";
            _uuidToDescription[Guid.Parse("00002ada-0000-1000-8000-00805f9b34fb")] = "Fitness Machine Status";
            _uuidToDescription[Guid.Parse("00002aed-0000-1000-8000-00805f9b34fb")] = "Date UTC";
            _uuidToDescription[Guid.Parse("00002b1d-0000-1000-8000-00805f9b34fb")] = "RC Feature";
            _uuidToDescription[Guid.Parse("00002b1e-0000-1000-8000-00805f9b34fb")] = "RC Settings";
            _uuidToDescription[Guid.Parse("00002b1f-0000-1000-8000-00805f9b34fb")] = "Reconnection Configuration Control Point";

            foreach (var (uuid, description) in _uuidToDescription)
            {
                _descriptionToUuid[description] = uuid;
            }
        }

        public bool TryGetDescription(Guid       uuid,
                                      out string description)
        {
            return _uuidToDescription.TryGetValue(uuid, out description);
        }

        public bool TryGetUuid(string description,
                                      out Guid uuid)
        {
            return _descriptionToUuid.TryGetValue(description, out uuid);
        }

    }

    public interface IAllGattCharacteristicsProvider
    {
        bool TryGetDescription(Guid       uuid,
                               out string description);

        bool TryGetUuid(string   description,
                        out Guid uuid);
    }
}