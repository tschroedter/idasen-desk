﻿using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics.Factories;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics.Factories
{
    public class GenericAccessFactory // todo generic factory
        : IGenericAccessFactory
    {
        private readonly GenericAccess.Factory _factory;

        public GenericAccessFactory([NotNull] GenericAccess.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }
        public IGenericAccess Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}