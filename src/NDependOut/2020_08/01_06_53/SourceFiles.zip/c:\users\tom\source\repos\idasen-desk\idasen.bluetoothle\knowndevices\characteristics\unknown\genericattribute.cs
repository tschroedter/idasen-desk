﻿using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics.Unknown
{
    public class GenericAttribute
        : UnknownBase, IGenericAttribute
    {
        public byte[] RawServiceChanged { get; } = RawArrayEmpty;
    }
}