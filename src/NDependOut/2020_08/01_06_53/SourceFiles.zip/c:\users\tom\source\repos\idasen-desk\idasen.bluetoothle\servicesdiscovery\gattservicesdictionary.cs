﻿using System.Collections.Generic;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;

namespace Idasen.BluetoothLE.ServicesDiscovery
{
    public class GattServicesDictionary
        : Dictionary<IGattDeviceServiceWrapper, IGattCharacteristicsResultWrapper>,
          IGattServicesDictionary
    {
        public new void Clear()
        {
            DisposeServices();

            base.Clear();
        }

        public void Dispose()
        {
            DisposeServices();
        }

        public IReadOnlyDictionary<IGattDeviceServiceWrapper, IGattCharacteristicsResultWrapper> ReadOnlyDictionary =>
            this;

        private void DisposeServices()
        {
            foreach (var service in Keys)
            {
                service.Dispose();
            }
        }
    }
}