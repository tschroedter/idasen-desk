﻿using System;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Idasen.BluetoothLE.Interfaces.KnownDevices;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices
{
    public class Desk
        : IDesk
    {
        private readonly IDeskCharacteristics _deskCharacteristics;
        private readonly IDevice              _device;
        private readonly ILogger              _logger;

        public Desk(
            [NotNull] ILogger              logger,
            [NotNull] IDevice              device,
            [NotNull] IDeskCharacteristics deskCharacteristics)
        {
            Guard.ArgumentNotNull(logger,
                                  nameof(logger));
            Guard.ArgumentNotNull(device,
                                  nameof(device));
            Guard.ArgumentNotNull(deskCharacteristics,
                                  nameof(deskCharacteristics));

            _logger              = logger;
            _device              = device;
            _deskCharacteristics = deskCharacteristics;

            _device.GattServicesRefreshed
                   .Subscribe(OnGattServicesRefreshed);
        }

        public void Connect()
        {
            _device.Connect();
        }

        private async void OnGattServicesRefreshed(GattCommunicationStatus status)
        {
            _logger.Information($"[{_device.DeviceId}] "                         +
                                $"ConnectionStatus: {_device.ConnectionStatus} " +
                                $"GattCommunicationStatus: {_device.GattCommunicationStatus}");

            _deskCharacteristics.Initialize(_device);

            await _deskCharacteristics.Refresh();

            _logger.Information($"{_deskCharacteristics}");
        }
    }
}