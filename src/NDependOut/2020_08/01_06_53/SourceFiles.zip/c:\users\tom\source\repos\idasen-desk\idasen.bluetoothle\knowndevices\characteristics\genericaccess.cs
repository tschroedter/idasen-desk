﻿using System;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class GenericAccess
        : CharacteristicBaseNew,
          IGenericAccess
    {
        public const string CharacteristicDeviceName = "Device Name";
        public const string CharacteristicAppearance = "Appearance";
        public const string CharacteristicParameters = "Peripheral Preferred Connection Parameters";
        public const string CharacteristicResolution = "Central Address Resolution";

        private readonly IAllGattCharacteristicsProvider _allGattCharacteristicsProvider;

        public delegate IGenericAccess Factory(IDevice device);

        public override Guid GattServiceUuid { get; } = Guid.Parse("00001800-0000-1000-8000-00805F9B34FB");

        public GenericAccess(
            ILogger                                   logger,
            IDevice                                   device,
            ICustomGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter,
            [NotNull] IAllGattCharacteristicsProvider allGattCharacteristicsProvider)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
            Guard.ArgumentNotNull(allGattCharacteristicsProvider,
                                  nameof(allGattCharacteristicsProvider));

            _allGattCharacteristicsProvider = allGattCharacteristicsProvider;
        }

        protected override T WithMapping<T>() where T : class
        {
            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicDeviceName,
                                                           out var uuid))
                DescriptionToUuid[CharacteristicDeviceName] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicAppearance,
                                                           out uuid))
                DescriptionToUuid[CharacteristicAppearance] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicParameters,
                                                           out uuid))
                DescriptionToUuid[CharacteristicParameters] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicResolution,
                                                           out uuid))
                DescriptionToUuid[CharacteristicResolution] = uuid;

            return this as T;
        }

        public byte[] RawCentralAddressResolution => TryGetValueOrEmpty(CharacteristicResolution);

        public byte[] RawPeripheralPreferredConnectionParameters => TryGetValueOrEmpty(CharacteristicParameters);

        public byte[] RawAppearance => TryGetValueOrEmpty(CharacteristicAppearance);

        public byte[] RawDeviceName => TryGetValueOrEmpty(CharacteristicDeviceName);
    }
}