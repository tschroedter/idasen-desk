﻿using System;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics
{
    public class GenericAttribute
        : CharacteristicBaseNew,
          IGenericAttribute
    {
        private readonly IAllGattCharacteristicsProvider _allGattCharacteristicsProvider;

        public const string CharacteristicServiceChanged = "Service Changed";

        public override Guid GattServiceUuid { get; } = Guid.Parse("00001801-0000-1000-8000-00805f9b34fb");

        public delegate IGenericAttribute Factory(IDevice device);

        public GenericAttribute(
            ILogger                                   logger,
            IDevice                                   device,
            ICustomGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter,
            [NotNull] IAllGattCharacteristicsProvider allGattCharacteristicsProvider)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
            Guard.ArgumentNotNull(allGattCharacteristicsProvider,
                                  nameof(allGattCharacteristicsProvider));

            _allGattCharacteristicsProvider = allGattCharacteristicsProvider;
        }

        public byte[] RawServiceChanged => TryGetValueOrEmpty(CharacteristicServiceChanged);

        protected override T WithMapping<T>() where T : class
        {
            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicServiceChanged,
                                                           out var uuid))
                DescriptionToUuid[CharacteristicServiceChanged] = uuid;

            return this as T;
        }
    }
}