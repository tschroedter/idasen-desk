﻿using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics.Unknown
{
    public class Dpg
        : UnknownBase, IDpg
    {
        public byte[] RawDpg { get; } = RawArrayEmpty;
    }
}