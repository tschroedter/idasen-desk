﻿using System.Diagnostics.CodeAnalysis;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Autofac;
using Idasen.BluetoothLE.DevicesDiscovery;
using Idasen.BluetoothLE.Interfaces;
using Idasen.BluetoothLE.Interfaces.DevicesDiscovery;
using Idasen.BluetoothLE.Interfaces.KnownDevices;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics.Factories;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Idasen.BluetoothLE.KnownDevices;
using Idasen.BluetoothLE.KnownDevices.Characteristics;
using Idasen.BluetoothLE.KnownDevices.Characteristics.Factories;
using Idasen.BluetoothLE.KnownDevices.Common;
using Idasen.BluetoothLE.ServicesDiscovery;
using Idasen.BluetoothLE.ServicesDiscovery.Wrappers;
using Device = Idasen.BluetoothLE.DevicesDiscovery.Device;
using DeviceFactory = Idasen.BluetoothLE.DevicesDiscovery.DeviceFactory;
using IDevice = Idasen.BluetoothLE.Interfaces.DevicesDiscovery.IDevice;
using IDeviceFactory = Idasen.BluetoothLE.Interfaces.DevicesDiscovery.IDeviceFactory;

namespace Idasen.BluetoothLE
{
    // ReSharper disable once InconsistentNaming
    [ExcludeFromCodeCoverage]
    public class BluetoothLEModule
        : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterGeneric(typeof(Subject<>))
                   .As(typeof(ISubject<>));

            builder.RegisterInstance(Scheduler.Default)
                   .As<IScheduler>();

            builder.RegisterType<ObservableTimerFactory>()
                   .As<IObservableTimerFactory>();

            builder.RegisterType<DateTimeOffsetWrapper>()
                   .As<IDateTimeOffset>();

            builder.RegisterType<DeviceComparer>()
                   .As<IDeviceComparer>();
            builder.RegisterType<Device>()
                   .As<IDevice>();
            builder.RegisterType<DeviceMonitor>()
                   .As<IDeviceMonitor>();
            builder.RegisterType<DeviceMonitorWithExpiry>()
                   .As<IDeviceMonitorWithExpiry>();
            builder.RegisterType<Devices>()
                   .As<IDevices>();
            builder.RegisterType<Watcher>()
                   .As<IWatcher>();
            builder.RegisterType<Wrapper>()
                   .As<IWrapper>();
            builder.RegisterType<DeviceFactory>()
                   .As<IDeviceFactory>();
            builder.RegisterType<StatusMapper>()
                   .As<IStatusMapper>();

            builder.RegisterType<MatchMaker>()
                   .As<IMatchMaker>();
            builder.RegisterType<BluetoothGattServices>()
                   .As<IBluetoothGattServices>();
            builder.RegisterType<GattServicesDictionary>()
                   .As<IGattServicesDictionary>();
            builder.RegisterType<GattServicesProvider>()
                   .As<IGattServicesProvider>();
            builder.RegisterType<GattServicesProviderFactory>()
                   .As<IGattServicesProviderFactory>();
            builder.RegisterType<ServicesDiscovery.Device>()
                   .As<Interfaces.ServicesDiscovery.IDevice>();
            builder.RegisterType<ServicesDiscovery.DeviceFactory>()
                   .As<Interfaces.ServicesDiscovery.IDeviceFactory>();

            builder.RegisterType<BluetoothLeDeviceWrapper>()
                   .As<IBluetoothLeDeviceWrapper>();
            builder.RegisterType<BluetoothLeDeviceWrapperFactory>()
                   .As<IBluetoothLeDeviceWrapperFactory>();
            builder.RegisterType<GattDeviceServicesResultWrapper>()
                   .As<IGattDeviceServicesResultWrapper>();
            builder.RegisterType<GattDeviceServicesResultWrapperFactory>()
                   .As<IGattDeviceServicesResultWrapperFactory>();

            builder.RegisterType<GattCharacteristicsResultWrapper>()
                   .As<IGattCharacteristicsResultWrapper>();
            builder.RegisterType<GattCharacteristicsResultWrapperFactory>()
                   .As<IGattCharacteristicsResultWrapperFactory>();

            builder.RegisterType<AllGattCharacteristicsProvider>()
                   .As<IAllGattCharacteristicsProvider>();

            builder.RegisterType<CustomGattCharacteristicProvider>()
                   .As<ICustomGattCharacteristicProvider>();

            builder.RegisterType<CustomGattCharacteristicsProviderFactory>()
                   .As<ICustomGattCharacteristicsProviderFactory>();

            builder.RegisterType<RawValueReader>()
                   .As<IRawValueReader>();

            builder.RegisterType<RawValueWriter>()
                   .As<IRawValueWriter>();

            builder.RegisterType<GenericAccess>()
                   .As<IGenericAccess>();

            builder.RegisterType<GenericAccessFactory>()
                   .As<IGenericAccessFactory>();

            builder.RegisterType<GenericAttribute>()
                   .As<IGenericAttribute>();

            builder.RegisterType<GenericAttributeFactory>()
                   .As<IGenericAttributeFactory>();

            builder.RegisterType<ReferenceInput>()
                   .As<IReferenceInput>();

            builder.RegisterType<ReferenceInputFactory>()
                   .As<IReferenceInputFactory>();

            builder.RegisterType<ReferenceOutput>()
                   .As<IReferenceOutput>();

            builder.RegisterType<ReferenceOutputFactory>()
                   .As<IReferenceOutputFactory>();

            builder.RegisterType<Dpg>()
                   .As<IDpg>();

            builder.RegisterType<DpgFactory>()
                   .As<IDpgFactory>();

            builder.RegisterType<Control>()
                   .As<IControl>();

            builder.RegisterType<ControlFactory>()
                   .As<IControlFactory>();

            builder.RegisterType<DeskCharacteristics>()
                   .As<IDeskCharacteristics>();

            builder.RegisterType<Desk>()
                   .As<IDesk>();
            builder.RegisterType<DeskFactory>()
                   .As<IDeskFactory>();
        }
    }
}