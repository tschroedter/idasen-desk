﻿using System;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Idasen.BluetoothLE.Interfaces.KnownDevices.Common;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.KnownDevices.Common
{
    public class RawValueWriter
        : IRawValueWriter
    {
        public async Task<bool> TryWriteValueAsync(
            [NotNull] GattCharacteristic characteristic,
            [NotNull] IBuffer            buffer)
        {
            Guard.ArgumentNotNull(characteristic,
                                  nameof(characteristic));
            Guard.ArgumentNotNull(buffer,
                                  nameof(buffer));

            if (SupportsWrite(characteristic))
            {
                Log.Information($"GattCharacteristic '{characteristic.Uuid}' doesn't support 'Write/WritableAuxiliaries/WriteWithoutResponse'");

                return false;
            }

            var status = await characteristic.WriteValueAsync(buffer);

            return status == GattCommunicationStatus.Success;
        }

        private static bool SupportsWrite(GattCharacteristic characteristic)
        {
            return (characteristic.CharacteristicProperties & GattCharacteristicProperties.Write) !=
                   GattCharacteristicProperties.Write;
        }

        public async Task<bool> TryWritableAuxiliariesValueAsync(
            [NotNull] GattCharacteristic characteristic,
            [NotNull] IBuffer            buffer)
        {
            Guard.ArgumentNotNull(characteristic,
                                  nameof(characteristic));
            Guard.ArgumentNotNull(buffer,
                                  nameof(buffer));

            if (SupportsWritableAuxiliaries(characteristic))
            {
                Log.Information($"GattCharacteristic '{characteristic.Uuid}' doesn't support 'Write/WritableAuxiliaries/WriteWithoutResponse'");

                return false;
            }

            var status = await characteristic.WriteValueAsync(buffer);

            return status == GattCommunicationStatus.Success;

        }

        private static bool SupportsWritableAuxiliaries(GattCharacteristic characteristic)
        {
            return (characteristic.CharacteristicProperties & GattCharacteristicProperties.WritableAuxiliaries) !=
                   GattCharacteristicProperties.WritableAuxiliaries;
        }

        public async Task<GattWriteResult> TryWriteWithoutResponseAsync(
            [NotNull] GattCharacteristic characteristic,
            [NotNull] IBuffer            buffer)
        {
            Guard.ArgumentNotNull(characteristic,
                                  nameof(characteristic));
            Guard.ArgumentNotNull(buffer,
                                  nameof(buffer));

            if (SupportsWriteWithoutResponse(characteristic))
            {
                Log.Information($"GattCharacteristic '{characteristic.Uuid}' doesn't support 'Write/WritableAuxiliaries/WriteWithoutResponse'");

                return null; // todo not nice
            }

            var status = await characteristic.WriteValueWithResultAsync(buffer);

            return status;

        }
        private static bool SupportsWriteWithoutResponse(GattCharacteristic characteristic)
        {
            return (characteristic.CharacteristicProperties & GattCharacteristicProperties.WriteWithoutResponse) !=
                   GattCharacteristicProperties.WriteWithoutResponse;
        }
    }
}