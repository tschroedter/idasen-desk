﻿using Idasen.BluetoothLE.Interfaces.KnownDevices.Characteristics;

namespace Idasen.BluetoothLE.KnownDevices.Characteristics.Unknown
{
    public class GenericReferenceInput
        : UnknownBase, IReferenceInput
    {
        public byte[] Ctrl1 { get; } = RawArrayEmpty;
    }
}