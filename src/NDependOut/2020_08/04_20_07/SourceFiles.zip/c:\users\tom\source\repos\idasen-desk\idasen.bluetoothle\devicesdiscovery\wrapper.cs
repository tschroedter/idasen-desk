﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Windows.Devices.Bluetooth.Advertisement;
using Idasen.BluetoothLE.Interfaces;
using Idasen.BluetoothLE.Interfaces.DevicesDiscovery;
using AdvertisementWatcher = Windows.Devices.Bluetooth.Advertisement.BluetoothLEAdvertisementWatcher;

namespace Idasen.BluetoothLE.DevicesDiscovery
{
    // ReSharper disable once InconsistentNaming
    [ExcludeFromCodeCoverage]
    public sealed class Wrapper
        : IWrapper
    {
        private readonly Func<DateTimeOffset, IDateTimeOffset> _dateTimeFactory;
        private readonly IDeviceFactory                        _deviceFactory;
        private readonly ISubject<IDevice>                     _received;
        private readonly IStatusMapper                         _statusMapper;
        private readonly ISubject<DateTime>                    _stopped;
        private readonly IDisposable                           _subscriberReceived;
        private readonly IDisposable                           _subscriberStopped;
        private readonly AdvertisementWatcher                  _watcher;

        public Wrapper(IDeviceFactory                        deviceFactory,
                       Func<DateTimeOffset, IDateTimeOffset> dateTimeFactory,
                       ISubject<IDevice>                     received,
                       ISubject<DateTime>                    stopped,
                       IStatusMapper                         statusMapper)
        {
            _deviceFactory   = deviceFactory;
            _dateTimeFactory = dateTimeFactory;
            _received        = received;
            _stopped         = stopped;
            _statusMapper    = statusMapper;

            _watcher = new AdvertisementWatcher
                       {
                           ScanningMode = BluetoothLEScanningMode.Active
                       };

            var fromReceivedEvent =
                Observable.FromEventPattern<BluetoothLEAdvertisementReceivedEventArgs>(_watcher,
                                                                                       "Received");
            var fromStoppedEvent =
                Observable.FromEventPattern<BluetoothLEAdvertisementWatcherStoppedEventArgs>(_watcher,
                                                                                             "Stopped");

            _subscriberReceived = fromReceivedEvent.Subscribe(OnReceived);
            _subscriberStopped  = fromStoppedEvent.Subscribe(OnStopped);
        }

        /// <inheritdoc />
        public IObservable<DateTime> Stopped => _stopped;

        /// <inheritdoc />
        public IObservable<IDevice> Received => _received;

        /// <inheritdoc />
        public Status Status => _statusMapper.Map(_watcher.Status);

        /// <inheritdoc />
        public void Start()
        {
            _watcher.Start();
        }

        /// <inheritdoc />
        public void Stop()
        {
            _watcher.Stop();
        }

        /// <inheritdoc />
        public void Dispose()
        {
            _subscriberReceived.Dispose();
            _subscriberStopped.Dispose();
        }

        private void OnReceived(EventPattern<BluetoothLEAdvertisementReceivedEventArgs> args)
        {
            var dateTimeOffset = _dateTimeFactory.Invoke(args.EventArgs.Timestamp);

            var device = _deviceFactory.Create(dateTimeOffset,
                                               args.EventArgs.BluetoothAddress,
                                               args.EventArgs.Advertisement.LocalName,
                                               args.EventArgs.RawSignalStrengthInDBm);

            _received.OnNext(device);
        }

        private void OnStopped(EventPattern<BluetoothLEAdvertisementWatcherStoppedEventArgs> args)
        {
            _stopped.OnNext(DateTime.Now);
        }
    }
}