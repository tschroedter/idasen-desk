﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using NotNullAttribute = JetBrains.Annotations.NotNullAttribute;

namespace Idasen.BluetoothLE.ServicesDiscovery
{
    /// <inheritdoc />
    [ExcludeFromCodeCoverage]
    public class DeviceFactory
        : IDeviceFactory
    {
        private readonly Device.Factory                   _deviceFactory;
        private readonly IBluetoothLeDeviceWrapperFactory _deviceWrapperFactory;


        public DeviceFactory(
            [NotNull] Device.Factory                   deviceFactory,
            [NotNull] IBluetoothLeDeviceWrapperFactory deviceWrapperFactory)
        {
            Guard.ArgumentNotNull(deviceFactory,
                                  nameof(deviceFactory));
            Guard.ArgumentNotNull(deviceWrapperFactory,
                                  nameof(deviceWrapperFactory));

            _deviceFactory        = deviceFactory;
            _deviceWrapperFactory = deviceWrapperFactory;
        }

        /// <inheritdoc />
        public async Task<IDevice> FromBluetoothAddressAsync(ulong address)
        {
            var device = await BluetoothLEDevice.FromBluetoothAddressAsync(address);

            return _deviceFactory(_deviceWrapperFactory.Create(device));
        }
    }
}