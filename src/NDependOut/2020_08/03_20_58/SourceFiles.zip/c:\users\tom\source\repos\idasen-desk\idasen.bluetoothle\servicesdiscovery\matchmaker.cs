﻿using System;
using System.Threading.Tasks;
using Idasen.BluetoothLE.Interfaces;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.ServicesDiscovery
{
    public class MatchMaker
        : IMatchMaker
    {
        private readonly IDeviceFactory _deviceFactory;
        private readonly ILogger        _logger;

        public MatchMaker([NotNull] ILogger            logger,
                          [NotNull] IBluetoothGattServices bluetoothGattServices,
                          [NotNull] IDeviceFactory     deviceFactory)
        {
            Guard.ArgumentNotNull(logger,
                                  nameof(logger));
            Guard.ArgumentNotNull(bluetoothGattServices,
                                  nameof(bluetoothGattServices));
            Guard.ArgumentNotNull(deviceFactory,
                                  nameof(deviceFactory));

            _logger        = logger;
            _deviceFactory = deviceFactory;
        }

        /// <summary>
        ///     Attempts to pair to BLE device by address.
        /// </summary>
        /// <param name="address">The BLE device address.</param>
        /// <returns></returns>
        public async Task<IDevice> PairToDeviceAsync(ulong address)
        {
            var device = await _deviceFactory.FromBluetoothAddressAsync(address);

            if (device == null)
            {
                var message = $"Failed to find device with address '{address}'";

                throw new ArgumentNullException(message);
            }

            _logger.Information($"DeviceId after FromBluetoothAddressAsync: {device.DeviceId}");
            _logger.Information($"ConnectionStatus after FromBluetoothAddressAsync: {device.ConnectionStatus}");

            return device;
        }
    }
}