﻿using System.Collections.Generic;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class GenericAccess
        : UnknownBase, IGenericAccess
    {
        public IEnumerable<byte> RawCentralAddressResolution                { get; } = RawArrayEmpty;
        public IEnumerable<byte> RawPeripheralPreferredConnectionParameters { get; } = RawArrayEmpty;
        public IEnumerable<byte> RawAppearance                              { get; } = RawArrayEmpty;
        public IEnumerable<byte> RawDeviceName                              { get; } = RawArrayEmpty;
    }
}