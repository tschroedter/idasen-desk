﻿using Idasen.BluetoothLE.Desk.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.Desk.Common
{
    public class CustomGattCharacteristicsProviderFactory
        : ICustomGattCharacteristicsProviderFactory
    {
        private readonly CustomGattCharacteristicProvider.Factory _factory;

        public CustomGattCharacteristicsProviderFactory(
            [NotNull] CustomGattCharacteristicProvider.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }

        public ICustomGattCharacteristicProvider Create(
            IGattCharacteristicsResultWrapper wrapper)
        {
            return _factory(wrapper);
        }
    }
}