﻿using System;
using System.Collections.Generic;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;
using Idasen.BluetoothLE.Desk.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Serilog;

namespace Idasen.BluetoothLE.Desk.Characteristics
{
    public class ReferenceInput
        : CharacteristicBase,
          IReferenceInput
    {
        public delegate IReferenceInput Factory(IDevice device);

        private const string KeyCtrl1 = "Ctrl1";
        private const string KeyCtrl2 = "Ctrl2";
        private const string KeyCtrl3 = "Ctrl3";
        private const string KeyCtrl4 = "Ctrl4";

        public ReferenceInput(
            ILogger                                   logger,
            IDevice                                   device,
            ICustomGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
        }

        public override Guid GattServiceUuid { get; } = Guid.Parse("99FA0030-338A-1024-8A49-009C0215F78A");


        public IEnumerable<byte> Ctrl1 => TryGetValueOrEmpty(KeyCtrl1);

        protected override T WithMapping<T>() where T : class
        {
            DescriptionToUuid[KeyCtrl1] = Guid.Parse("99FA0031-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}