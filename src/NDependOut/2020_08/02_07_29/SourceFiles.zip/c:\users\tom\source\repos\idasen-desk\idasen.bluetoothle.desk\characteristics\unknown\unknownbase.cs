﻿using System.Linq;
using System.Threading.Tasks;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class UnknownBase : ICharacteristicBase
    {
        protected static readonly byte[] RawArrayEmpty = Enumerable.Empty<byte>()
                                                                   .ToArray();

        public T Initialize<T>() where T : class
        {
            return this as T;
        }

        public Task Refresh()
        {
            return Task.FromResult(false);
        }
    }
}