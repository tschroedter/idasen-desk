﻿using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class GenericAccess
        : UnknownBase, IGenericAccess
    {
        public byte[] RawCentralAddressResolution                { get; } = RawArrayEmpty;
        public byte[] RawPeripheralPreferredConnectionParameters { get; } = RawArrayEmpty;
        public byte[] RawAppearance                              { get; } = RawArrayEmpty;
        public byte[] RawDeviceName                              { get; } = RawArrayEmpty;
    }
}