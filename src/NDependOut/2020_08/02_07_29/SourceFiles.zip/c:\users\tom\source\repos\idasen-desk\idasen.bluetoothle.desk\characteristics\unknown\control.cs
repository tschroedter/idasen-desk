﻿using System;
using System.Threading.Tasks;
using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class Control
        : UnknownBase, IControl
    {
        public byte[] RawControl2 { get; } = RawArrayEmpty;
        public byte[] RawControl3 { get; } = RawArrayEmpty;

        public Task<bool> TryWriteRawControl2(byte[] bytes)
        {
            throw new NotImplementedException();
        }
    }
}