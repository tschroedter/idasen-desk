﻿using System;

namespace Idasen.BluetoothLE.KnownDevices
{
    public static class ByteArrayExtensions
    {
        public static string ToHex(this byte[] array)
        {
            return BitConverter.ToString(array); //.Replace("-", "");
        }
    }
}