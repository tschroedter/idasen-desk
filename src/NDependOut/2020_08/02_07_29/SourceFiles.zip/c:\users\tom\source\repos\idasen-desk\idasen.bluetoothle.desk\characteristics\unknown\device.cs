﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class Device
        : IDevice
    {
        public void Dispose()
        {
        }

        public IObservable<BluetoothConnectionStatus> ConnectionStatusChanged { get; } = null;
        public GattCommunicationStatus GattCommunicationStatus { get; } = GattCommunicationStatus.Unreachable;
        public string Name { get; } = "Unknown Device";
        public string DeviceId { get; } = "Unknown Device Id";
        public bool IsPaired { get; } = false;
        public BluetoothConnectionStatus ConnectionStatus { get; } = BluetoothConnectionStatus.Disconnected;

        public IReadOnlyDictionary<IGattDeviceServiceWrapper, IGattCharacteristicsResultWrapper> GattServices { get; } =
            new Dictionary<IGattDeviceServiceWrapper, IGattCharacteristicsResultWrapper>().ToImmutableDictionary();

        public IObservable<GattCommunicationStatus> GattServicesRefreshed { get; } = null;

        public void Connect()
        {
            throw new NotImplementedException();
        }
    }
}