﻿using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class GenericReferenceInput
        : UnknownBase, IReferenceInput
    {
        public byte[] Ctrl1 { get; } = RawArrayEmpty;
    }
}