﻿using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class GenericAttribute
        : UnknownBase, IGenericAttribute
    {
        public byte[] RawServiceChanged { get; } = RawArrayEmpty;
    }
}