﻿using System;
using System.Reactive.Linq;
using Autofac;
using AutofacSerilogIntegration;
using Idasen.BluetoothLE;
using Idasen.BluetoothLE.Desk;
using Idasen.BluetoothLE.Desk.Interfaces;
using Idasen.BluetoothLE.Interfaces.DevicesDiscovery;
using Serilog;
using Serilog.Events;
using static System.Console;

namespace Idasen.ConsoleApp
{
    internal sealed class Program
    {
        private static ILogger     _logger;
        private static IDeskFactory _deskFactory;
        private static IDesk _desk;

        private static void Main()
        {
            const string template =
                "[{Timestamp:HH:mm:ss.ffff} {Level:u3}] {Message}{NewLine}{Exception}";
            // "[{Timestamp:HH:mm:ss.ffff} {Level:u3}] {Message} (at {Caller}){NewLine}{Exception}";

            Log.Logger = new LoggerConfiguration()
                        .Enrich.WithCaller()
                        .MinimumLevel.Information()
                        .WriteTo.ColoredConsole(LogEventLevel.Debug, template)
                        .CreateLogger();

            var builder = new ContainerBuilder();

            builder.RegisterLogger();
            builder.RegisterModule<BluetoothLEModule>();
            builder.RegisterModule<BluetoothLEDeskModule>();

            var container = builder.Build();

            _logger = container.Resolve<ILogger>();

            _deskFactory = container.Resolve<IDeskFactory>();

            var monitor = container.Resolve<IDeviceMonitorWithExpiry>();

            var updated     = monitor.DeviceUpdated.Subscribe(OnDeviceUpdated);
            var discovered  = monitor.DeviceDiscovered.Subscribe(OnDeviceDiscovered);
            var nameChanged = monitor.DeviceNameUpdated.Subscribe(OnDeviceNameChanged);
            var deskFound = monitor.DeviceNameUpdated
                                   .Where(device => device.Name.StartsWith("Desk"))
                                   .Subscribe(OnDeskDiscovered);

            monitor.Start();

            ReadLine();

            monitor.Stop();

            deskFound.Dispose();
            nameChanged.Dispose();
            discovered.Dispose();
            updated.Dispose();

            container.Dispose();
        }

        internal static async void OnDeskDiscovered(IDevice device)
        {
            try
            {
                _desk = await _deskFactory.CreateAsync(device.Address);
                _desk.Connect();
            }
            catch (Exception e)
            {
                WriteLine(e);
                throw;
            }
        }

        private static void OnDeviceUpdated(IDevice device)
        {
            _logger.Information($"Device Updated: {device}");
            //_logger.Information($"{DevicesToString(_monitor.DiscoveredDevices)}");
        }

        private static void OnDeviceDiscovered(IDevice device)
        {
            _logger.Information($"Device Discovered: {device}");
        }

        private static void OnDeviceNameChanged(IDevice device)
        {
            _logger.Information($"Device Name Changed: {device}");
        }
    }
}