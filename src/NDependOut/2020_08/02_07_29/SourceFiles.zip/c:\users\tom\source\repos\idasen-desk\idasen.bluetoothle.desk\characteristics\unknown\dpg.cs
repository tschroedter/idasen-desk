﻿using Idasen.BluetoothLE.Desk.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Desk.Characteristics.Unknown
{
    public class Dpg
        : UnknownBase, IDpg
    {
        public byte[] RawDpg { get; } = RawArrayEmpty;
    }
}