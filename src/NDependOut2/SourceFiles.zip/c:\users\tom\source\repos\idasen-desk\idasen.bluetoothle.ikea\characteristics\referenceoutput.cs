﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Idasen.BluetoothLE.Ikea.Common;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Customs;
using Idasen.BluetoothLE.Ikea.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Idasen.BluetoothLE.ServicesDiscovery.Wrappers;
using Serilog;

namespace Idasen.BluetoothLE.Ikea.Characteristics
{
    public class ReferenceOutput
        : CharacteristicBase,
          IReferenceOutput
    {
        private IDisposable _subscriber;

        public delegate IReferenceOutput Factory(IDevice device);

        private const string KeyHeightSpeed = "Height Speed";
        private const string KeyTwo         = "TWO";
        private const string KeyThree       = "THREE";
        private const string KeyFour        = "FOUR";
        private const string KeyFive        = "FIVE";
        private const string KeySix         = "SIX";
        private const string KeySeven       = "SEVEN";
        private const string KeyEight       = "EIGHT";
        private const string KeyMask        = "MASK";
        private const string KeyDetectMask  = "DETECT MASK";

        public ReferenceOutput(
            ILogger                                   logger,
            IDevice                                   device,
            IGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
        }

        public override Guid GattServiceUuid { get; } = Guid.Parse("99FA0020-338A-1024-8A49-009C0215F78A");

        public IEnumerable<byte> RawHeightSpeed => TryGetValueOrEmpty(KeyHeightSpeed);
        public IEnumerable<byte> RawTwo         => TryGetValueOrEmpty(KeyTwo);
        public IEnumerable<byte> RawThree       => TryGetValueOrEmpty(KeyThree);
        public IEnumerable<byte> RawFour        => TryGetValueOrEmpty(KeyFour);
        public IEnumerable<byte> RawFive        => TryGetValueOrEmpty(KeyFive);
        public IEnumerable<byte> RawSix         => TryGetValueOrEmpty(KeySix);
        public IEnumerable<byte> RawSeven       => TryGetValueOrEmpty(KeySeven);
        public IEnumerable<byte> RawEight       => TryGetValueOrEmpty(KeyEight);
        public IEnumerable<byte> RawMask        => TryGetValueOrEmpty(KeyMask);
        public IEnumerable<byte> RawDetectMask  => TryGetValueOrEmpty(KeyDetectMask);

        protected override T WithMapping<T>() where T : class
        {
            DescriptionToUuid[KeyHeightSpeed] = Guid.Parse("99FA0021-338A-1024-8A49-009C0215F78A");
            DescriptionToUuid[KeyMask]        = Guid.Parse("99FA0029-338A-1024-8A49-009C0215F78A");
            DescriptionToUuid[KeyDetectMask]  = Guid.Parse("99FA002A-338A-1024-8A49-009C0215F78A");

            return this as T;
        }

        public override T Initialize<T>()
        {
            base.Initialize<T>();

            return this as T;
        }

        public override async Task Refresh()
        {
            await base.Refresh();

            var heightAndSpeed = Characteristics.Characteristics[KeyHeightSpeed];

            if (heightAndSpeed == null)
                return; // todo log error

            _subscriber = heightAndSpeed.ValueChanged.Subscribe(OnValueChanged);
        }

        private void OnValueChanged(ValueChangedDetails details)
        {
            Logger.Information($"{details.Uuid} {details.Timestamp} Value changed to {details.Value.ToHex()}");
        }

        public void Dispose()
        {
            _subscriber?.Dispose();
        }
    }
}