﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using Autofac;
using AutofacSerilogIntegration;
using Idasen.BluetoothLE;
using Idasen.BluetoothLE.Ikea;
using Idasen.BluetoothLE.Ikea.Common;
using Idasen.BluetoothLE.Ikea.Interfaces;
using Idasen.BluetoothLE.Interfaces.DevicesDiscovery;
using Serilog;
using Serilog.Events;

namespace Idasen.ConsoleApp
{
    public class Demo
        : IDisposable
    {
        private readonly IContainer               _container;
        private readonly IDeskFactory             _deskFactory;
        private readonly IDisposable              _deskFound;
        private readonly IDisposable              _discovered;
        private readonly ILogger                  _logger;
        private readonly IDeviceMonitorWithExpiry _monitor;
        private readonly IDisposable              _nameChanged;
        private readonly IDisposable              _updated;

        private IDesk _desk;
        private IDisposable _subscriberDeskDeviceNameChanged;

        public Demo()
        {
            const string template =
                "[{Timestamp:HH:mm:ss.ffff} {Level:u3}] {Message}{NewLine}{Exception}";
            // "[{Timestamp:HH:mm:ss.ffff} {Level:u3}] {Message} (at {Caller}){NewLine}{Exception}";

            Log.Logger = new LoggerConfiguration()
                        .Enrich.WithCaller()
                        .MinimumLevel.Information()
                        .WriteTo.ColoredConsole(LogEventLevel.Debug, template)
                        .CreateLogger();

            var builder = new ContainerBuilder();

            builder.RegisterLogger();
            builder.RegisterModule<BluetoothLEModule>();
            builder.RegisterModule<BluetoothLEDeskModule>();

            _container = builder.Build();

            _logger      = _container.Resolve<ILogger>();
            _deskFactory = _container.Resolve<IDeskFactory>();
            _monitor     = _container.Resolve<IDeviceMonitorWithExpiry>();

            _updated     = _monitor.DeviceUpdated.Subscribe(OnDeviceUpdated);
            _discovered  = _monitor.DeviceDiscovered.Subscribe(OnDeviceDiscovered);
            _nameChanged = _monitor.DeviceNameUpdated.Subscribe(OnDeviceNameChanged);
            _deskFound = _monitor.DeviceNameUpdated
                                 .Where(device => device.Name.StartsWith("Desk") ||
                                                  device.Address == 250635178951455)
                                 .Subscribe(OnDeskDiscovered);
        }

        public void Dispose()
        {
            _subscriberDeskDeviceNameChanged?.Dispose();
            _deskFound?.Dispose(); // todo list
            _nameChanged?.Dispose();
            _discovered?.Dispose();
            _updated?.Dispose();
            _monitor?.Dispose();
            _container?.Dispose();
        }

        public void Start()
        {
            _monitor.Start();
        }

        public void Stop()
        {
            _monitor.Stop();
        }

        private async void OnDeskDiscovered(IDevice device)
        {
            if (_desk != null)
                return;

            try
            {
                _desk = await _deskFactory.CreateAsync(device.Address);
                _subscriberDeskDeviceNameChanged =
                    _desk.DeviceNameChanged.Subscribe(OnDeskDeviceNameChanged);
                _desk.Connect();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        private void OnDeskDeviceNameChanged(IEnumerable<byte> value)
        {
            var array = value.ToArray();

            var text = System.Text.Encoding.UTF8.GetString(array);

            _logger.Information($"Received: {array.ToHex()} - '{text}'");
        }

        private void OnDeviceUpdated(IDevice device)
        {
            _logger.Information($"Device Updated: {device}");
            //Logger.Information($"{DevicesToString(_monitor.DiscoveredDevices)}");
        }

        private void OnDeviceDiscovered(IDevice device)
        {
            _logger.Information($"Device Discovered: {device}");
        }

        private void OnDeviceNameChanged(IDevice device)
        {
            _logger.Information($"Device Name Changed: {device}");
        }
    }
}