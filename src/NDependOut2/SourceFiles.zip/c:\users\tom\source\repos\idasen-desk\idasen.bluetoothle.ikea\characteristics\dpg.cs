﻿using System;
using System.Collections.Generic;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Customs;
using Idasen.BluetoothLE.Ikea.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Serilog;

namespace Idasen.BluetoothLE.Ikea.Characteristics
{
    public class Dpg
        : CharacteristicBase,
          IDpg
    {
        public delegate IDpg Factory(IDevice device);

        private const string KeyDpg = "Dpg";

        public Dpg(
            ILogger                                   logger,
            IDevice                                   device,
            IGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
        }

        public override Guid GattServiceUuid { get; } = Guid.Parse("99FA0010-338A-1024-8A49-009C0215F78A");


        public IEnumerable<byte> RawDpg => TryGetValueOrEmpty(KeyDpg);

        protected override T WithMapping<T>() where T : class
        {
            DescriptionToUuid[KeyDpg] = Guid.Parse("99FA0011-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}