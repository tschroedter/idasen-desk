﻿using System;

namespace Idasen.BluetoothLE.Ikea
{
    public class NotInitializeException
        : Exception
    {
        public NotInitializeException(string message)
            : base(message)
        {
        }
    }
}