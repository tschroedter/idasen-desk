﻿using System.Diagnostics;
using System.Globalization;
using Idasen.BluetoothLE.Interfaces;
using Idasen.BluetoothLE.Interfaces.DevicesDiscovery;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.DevicesDiscovery
{
    /// <inheritdoc />
    [DebuggerDisplay("{Address} {Name}")]
    public class Device
        : IDevice
    {
        public delegate IDevice Factory(IDateTimeOffset broadcastTime,
                                        ulong           address,
                                        string          name,
                                        short           rawSignalStrengthInDBm);

        private string _name;

        public Device([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            BroadcastTime          = device.BroadcastTime;
            Address                = device.Address;
            Name                   = device.Name;
            RawSignalStrengthInDBm = device.RawSignalStrengthInDBm;
        }

        public Device([NotNull] IDateTimeOffset broadcastTime,
                      ulong                     address,
                      string                    name,
                      short                     rawSignalStrengthInDBm)
        {
            Guard.ArgumentNotNull(broadcastTime,
                                  nameof(broadcastTime));

            BroadcastTime          = broadcastTime;
            Address                = address;
            Name                   = name ?? string.Empty;
            RawSignalStrengthInDBm = rawSignalStrengthInDBm;
        }

        /// <inheritdoc />
        public IDateTimeOffset BroadcastTime { get; set; }

        /// <inheritdoc />
        public ulong Address { get; }

        /// <inheritdoc />
        public string Name
        {
            get => _name;
            set => _name = value ?? string.Empty;
        }

        /// <inheritdoc />
        public short RawSignalStrengthInDBm { get; set; }

        /// <inheritdoc />
        public override string ToString()
        {
            var name = string.IsNullOrWhiteSpace(Name)
                           ? "[No Name]"
                           : Name;

            return
                $"{name} {Address} "                                              +
                $"({BroadcastTime.ToString("O", CultureInfo.InvariantCulture)}, " +
                $"{RawSignalStrengthInDBm}dB)";
        }
    }
}