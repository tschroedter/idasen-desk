﻿using System.Diagnostics.CodeAnalysis;
using Autofac;
using Idasen.BluetoothLE.Ikea.Characteristics;
using Idasen.BluetoothLE.Ikea.Characteristics.Customs;
using Idasen.BluetoothLE.Ikea.Characteristics.Factories;
using Idasen.BluetoothLE.Ikea.Common;
using Idasen.BluetoothLE.Ikea.Interfaces;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Customs;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Factories;
using Idasen.BluetoothLE.Ikea.Interfaces.Common;

namespace Idasen.BluetoothLE.Ikea
{
    // ReSharper disable once InconsistentNaming
    [ExcludeFromCodeCoverage]
    public class BluetoothLEDeskModule
        : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<BluetoothLEModule>();

            builder.RegisterType<AllGattCharacteristicsProvider>()
                   .As<IAllGattCharacteristicsProvider>();

            builder.RegisterType<GattCharacteristicProvider>()
                   .As<IGattCharacteristicProvider>();

            builder.RegisterType<GattCharacteristicsProviderFactory>()
                   .As<IGattCharacteristicsProviderFactory>();

            builder.RegisterType<RawValueReader>()
                   .As<IRawValueReader>();

            builder.RegisterType<RawValueWriter>()
                   .As<IRawValueWriter>();

            builder.RegisterType<GenericAccess>()
                   .As<IGenericAccess>();

            builder.RegisterType<GenericAccessFactory>()
                   .As<IGenericAccessFactory>();

            builder.RegisterType<GenericAttribute>()
                   .As<IGenericAttribute>();

            builder.RegisterType<GenericAttributeFactory>()
                   .As<IGenericAttributeFactory>();

            builder.RegisterType<ReferenceInput>()
                   .As<IReferenceInput>();

            builder.RegisterType<ReferenceInputFactory>()
                   .As<IReferenceInputFactory>();

            builder.RegisterType<ReferenceOutput>()
                   .As<IReferenceOutput>();

            builder.RegisterType<ReferenceOutputFactory>()
                   .As<IReferenceOutputFactory>();

            builder.RegisterType<Dpg>()
                   .As<IDpg>();

            builder.RegisterType<DpgFactory>()
                   .As<IDpgFactory>();

            builder.RegisterType<Control>()
                   .As<IControl>();

            builder.RegisterType<ControlFactory>()
                   .As<IControlFactory>();

            builder.RegisterType<DeskCharacteristics>()
                   .As<IDeskCharacteristics>();

            builder.RegisterType<Desk>()
                   .As<IDesk>();

            builder.RegisterType<DeskFactory>()
                   .As<IDeskFactory>();
        }
    }
}