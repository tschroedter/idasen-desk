﻿using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Factories;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Factories
{
    public class ReferenceInputFactory // todo generic factory
        : IReferenceInputFactory
    {
        private readonly ReferenceInput.Factory _factory;

        public ReferenceInputFactory([NotNull] ReferenceInput.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }

        public IReferenceInput Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}