﻿using System;
using System.Collections.Generic;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Customs;
using Idasen.BluetoothLE.Ikea.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Serilog;

namespace Idasen.BluetoothLE.Ikea.Characteristics
{
    public class ReferenceInput
        : CharacteristicBase,
          IReferenceInput
    {
        public delegate IReferenceInput Factory(IDevice device);

        private const string KeyCtrl1 = "Ctrl1";

        public ReferenceInput(
            ILogger                                   logger,
            IDevice                                   device,
            IGattCharacteristicsProviderFactory providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
        }

        public override Guid GattServiceUuid { get; } = Guid.Parse("99FA0030-338A-1024-8A49-009C0215F78A");

        public IEnumerable<byte> Ctrl1 => TryGetValueOrEmpty(KeyCtrl1);

        protected override T WithMapping<T>() where T : class
        {
            DescriptionToUuid[KeyCtrl1] = Guid.Parse("99FA0031-338A-1024-8A49-009C0215F78A");

            return this as T;
        }
    }
}