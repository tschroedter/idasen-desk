﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Subjects;
using System.Text;
using System.Threading.Tasks;
using Idasen.BluetoothLE.Ikea.Characteristics.Unknowns;
using Idasen.BluetoothLE.Ikea.Interfaces;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Factories;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using Serilog;
using NotNullAttribute = JetBrains.Annotations.NotNullAttribute;

namespace Idasen.BluetoothLE.Ikea
{
    public class DeskCharacteristics
        : IDeskCharacteristics
    {
        [NotNull] private readonly IControlFactory          _controlFactory;
        [NotNull] private readonly IDpgFactory              _dpgFactory;
        [NotNull] private readonly IGenericAccessFactory    _genericAccessFactory;
        [NotNull] private readonly IGenericAttributeFactory _genericAttributeFactory;
        [NotNull] private readonly ILogger                  _logger;
        [NotNull] private readonly IReferenceInputFactory   _referenceInputFactory;
        [NotNull] private readonly IReferenceOutputFactory  _referenceOutputFactory;

        [SuppressMessage("NDepend",
                         "ND1004:AvoidMethodsWithTooManyParameters",
                         Justification = "The real desk contains all the GATT characteristics.")]
        public DeskCharacteristics(
            [NotNull] ILogger                  logger,
            [NotNull] IGenericAccessFactory    genericAccessFactory,
            [NotNull] IGenericAttributeFactory genericAttributeFactory,
            [NotNull] IReferenceInputFactory   referenceInputFactory,
            [NotNull] IReferenceOutputFactory  referenceOutputFactory,
            [NotNull] IDpgFactory              dpgFactory,
            [NotNull] IControlFactory          controlFactory)
        {

            Guard.ArgumentNotNull(logger,
                                  nameof(logger));
            Guard.ArgumentNotNull(genericAccessFactory,
                                  nameof(genericAccessFactory));
            Guard.ArgumentNotNull(genericAttributeFactory,
                                  nameof(genericAttributeFactory));
            Guard.ArgumentNotNull(referenceInputFactory,
                                  nameof(referenceInputFactory));
            Guard.ArgumentNotNull(referenceOutputFactory,
                                  nameof(referenceOutputFactory));
            Guard.ArgumentNotNull(dpgFactory,
                                  nameof(dpgFactory));
            Guard.ArgumentNotNull(controlFactory,
                                  nameof(controlFactory));

            _logger                  = logger;
            _genericAccessFactory    = genericAccessFactory;
            _genericAttributeFactory = genericAttributeFactory;
            _referenceInputFactory   = referenceInputFactory;
            _referenceOutputFactory  = referenceOutputFactory;
            _dpgFactory              = dpgFactory;
            _controlFactory          = controlFactory;
        }

        public IDevice Device { get; } = new Device();

        public IGenericAccess    GenericAccess    { get; private set; } = new GenericAccess();
        public IGenericAttribute GenericAttribute { get; private set; } = new GenericAttribute();
        public IReferenceInput   ReferenceInput   { get; private set; } = new ReferenceInput();
        public IReferenceOutput  ReferenceOutput  { get; private set; } = new ReferenceOutput();
        public IDpg              Dpg              { get; private set; } = new Dpg();
        public IControl          Control          { get; private set; } = new Control();

        public async Task Refresh()
        {
            _logger.Debug($"[{Device}] Refreshing characteristics...");

            await GenericAccess.Refresh();
            await GenericAttribute.Refresh();
            await ReferenceInput.Refresh();
            await ReferenceOutput.Refresh();
            await Dpg.Refresh();
            await Control.Refresh();
        }

        public override string ToString()
        {
            var builder = new StringBuilder();

            builder.AppendLine(GenericAccess.ToString());
            builder.AppendLine(GenericAttribute.ToString());
            builder.AppendLine(ReferenceInput.ToString());
            builder.AppendLine(ReferenceOutput.ToString());
            builder.AppendLine(Dpg.ToString());
            builder.AppendLine(Control.ToString());

            return builder.ToString();
        }

        public IDeskCharacteristics Initialize(IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            GenericAccess = _genericAccessFactory.Create(device);
            GenericAccess.Initialize<Characteristics.GenericAccess>();

            GenericAttribute = _genericAttributeFactory.Create(device);
            GenericAttribute.Initialize<Characteristics.GenericAttribute>();

            ReferenceInput = _referenceInputFactory.Create(device);
            ReferenceInput.Initialize<Characteristics.GenericAttribute>();

            ReferenceOutput = _referenceOutputFactory.Create(device);
            ReferenceOutput.Initialize<Characteristics.ReferenceOutput>();

            Dpg = _dpgFactory.Create(device);
            Dpg.Initialize<Characteristics.Dpg>();

            Control = _controlFactory.Create(device);
            Control.Initialize<Characteristics.Control>();

            return this;
        }
    }
}