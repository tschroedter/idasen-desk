﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Idasen.BluetoothLE.Ikea.Common;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Customs;
using Idasen.BluetoothLE.Ikea.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.Ikea.Characteristics
{
    public abstract class CharacteristicBase
        : ICharacteristicBase
    {
        protected static readonly IEnumerable<byte> RawArrayEmpty = Enumerable.Empty<byte>()
                                                                              .ToArray();

        protected readonly Dictionary<string, Guid> DescriptionToUuid =
            new Dictionary<string, Guid>();

        protected readonly IDevice                                   Device;
        protected readonly ILogger                                   Logger;
        protected readonly IGattCharacteristicsProviderFactory ProviderFactory;
        protected readonly IRawValueReader                           RawValueReader;

        protected readonly Dictionary<string, IEnumerable<byte>>
            RawValues = new Dictionary<string, IEnumerable<byte>>();

        protected readonly IRawValueWriter ValueWriter;

        protected IGattCharacteristicProvider
            Characteristics; // todo rename to ICustomGattCharacteristic(s)Provider

        protected CharacteristicBase(
            [NotNull] ILogger                                   logger,
            [NotNull] IDevice                                   device,
            [NotNull] IGattCharacteristicsProviderFactory providerFactory,
            [NotNull] IRawValueReader                           rawValueReader,
            [NotNull] IRawValueWriter                           valueWriter)
        {
            Guard.ArgumentNotNull(logger,
                                  nameof(logger));
            Guard.ArgumentNotNull(device,
                                  nameof(device));
            Guard.ArgumentNotNull(providerFactory,
                                  nameof(providerFactory));
            Guard.ArgumentNotNull(rawValueReader,
                                  nameof(rawValueReader));
            Guard.ArgumentNotNull(valueWriter,
                                  nameof(valueWriter));

            Device          = device;
            Logger          = logger;
            ProviderFactory = providerFactory;
            RawValueReader  = rawValueReader;
            ValueWriter     = valueWriter;
        }

        public abstract Guid GattServiceUuid { get; }

        public virtual T Initialize<T>()
            where T : class
        {
            Guard.ArgumentNotNull(GattServiceUuid, // todo log error/warning
                                  nameof(GattServiceUuid));

            var (service, characteristicsResultWrapper) = Device.GattServices
                                                                .FirstOrDefault(x => x.Key.Uuid == GattServiceUuid);

            if (service == null)
                throw new ArgumentException("Failed, can't find GattDeviceService for " +
                                            $"UUID {GattServiceUuid}",
                                            nameof(GattServiceUuid));

            Logger.Debug($"Found GattDeviceService with UUID {GattServiceUuid}");

            Characteristics = ProviderFactory.Create(characteristicsResultWrapper);

            WithMapping<T>();

            return this as T;
        }

        public virtual async Task Refresh()
        {
            Characteristics.Refresh(DescriptionToUuid);

            foreach (var keyValuePair in Characteristics.Characteristics)
            {
                Logger.Information($"Reading raw value for {keyValuePair.Key} " +
                                   $"and and characteristic {keyValuePair.Value}");

                (bool success, byte[] value) result =
                    await RawValueReader.TryReadValueAsync(keyValuePair.Value);

                RawValues[keyValuePair.Key] = result.success
                                                  ? result.value
                                                  : RawArrayEmpty;
            }
        }

        protected abstract T WithMapping<T>() // todo maybe, no T and different name
            where T : class;

        protected async Task<bool> TryWriteValueAsync(string key,
                                                      byte[] bytes)
        {
            var characteristic = Characteristics.Characteristics[key];

            if (characteristic != null)
                return await ValueWriter.TryWriteValueAsync(characteristic,
                                                            bytes.AsBuffer());

            Logger.Error($"Unknown characteristic with key '{key}'");

            return false;
        }

        protected IEnumerable<byte> TryGetValueOrEmpty(string key)
        {
            return RawValues.TryGetValue(key,
                                         out var values)
                       ? values
                       : RawArrayEmpty;
        }

        protected string RawValueOrUnavailable(string            key,
                                               IEnumerable<byte> value)
        {
            return Characteristics.Characteristics
                                   .ContainsKey(key)
                       ? $"{key} = [{value.ToHex()}]"
                       : $"{key} = Unavailable";
        }

        protected string PropertiesToString(GattCharacteristicProperties properties) // todo duplicated code
        {
            var list = new List<GattCharacteristicProperties>();

            foreach (GattCharacteristicProperties property in Enum.GetValues(typeof(GattCharacteristicProperties)))
            {
                if ((properties & property) == property) list.Add(property);
            }

            return string.Join(", ", list);
        }

        public override string ToString()
        {
            var builder = new StringBuilder();

            builder.AppendLine($"{GetType().Name}");

            foreach (var key in DescriptionToUuid.Keys)
            {
                var rawValueOrUnavailable = RawValueOrUnavailable(key,
                                                                  TryGetValueOrEmpty(key));

                builder.Append(rawValueOrUnavailable);

                if (Characteristics.Properties.TryGetValue(key,
                                                            out var properties)
                )
                    builder.AppendLine($" ({PropertiesToString(properties)})");
                else
                    builder.AppendLine();
            }

            return builder.ToString();
        }
    }
}