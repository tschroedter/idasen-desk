﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Subjects;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using Serilog;
using NotNullAttribute = JetBrains.Annotations.NotNullAttribute;

namespace Idasen.BluetoothLE.ServicesDiscovery.Wrappers
{
    /// <inheritdoc />
    [ExcludeFromCodeCoverage]
    public class GattCharacteristicWrapper
        : IGattCharacteristicWrapper
    {
        public delegate IGattCharacteristicWrapper Factory(GattCharacteristic characteristic);

        private readonly ILogger _logger;
        private readonly ISubject<ValueChangedDetails> _valueChanged;
        private readonly GattCharacteristic _characteristic;    // todo use it

        public IObservable<ValueChangedDetails> ValueChanged => _valueChanged; // todo change all ISUbject to IObserabale

        public GattCharacteristicWrapper(
            [NotNull] ILogger logger,
            [NotNull] ISubject<ValueChangedDetails> valueChanged,
            [NotNull] GattCharacteristic characteristic)
        {
            Guard.ArgumentNotNull(logger, nameof(logger));
            Guard.ArgumentNotNull(valueChanged,
                                  nameof(valueChanged));
            Guard.ArgumentNotNull(characteristic,
                                  nameof(characteristic));

            _logger = logger;
            _valueChanged = valueChanged;
            _characteristic = characteristic;
        }

        public async Task<IGattCharacteristicWrapper> Initialize()
        {
            if (!_characteristic.CharacteristicProperties.HasFlag(GattCharacteristicProperties.Notify) &&
                !_characteristic.CharacteristicProperties.HasFlag(GattCharacteristicProperties.Indicate))
                return this;

            // move if to async initialize method
            //subscribe to the GATT characteristic's notification
            var value = _characteristic.CharacteristicProperties.HasFlag(GattCharacteristicProperties.Notify)
                            ? GattClientCharacteristicConfigurationDescriptorValue.Notify
                            : GattClientCharacteristicConfigurationDescriptorValue.Indicate;

            GattCommunicationStatus status =
                await _characteristic.WriteClientCharacteristicConfigurationDescriptorAsync(value);

            if (status == GattCommunicationStatus.Success)
            {
                _logger.Information($"Service UUID = {_characteristic.Service.Uuid} "  +
                                    $"Characteristic UUID = {_characteristic.Uuid} - " +
                                    $"Subscribing to ValueChanged '{_characteristic.UserDescription}'");
                _characteristic.ValueChanged += OnValueChanged;
            }
            else
            {
                throw new Exception($"Service UUID = {_characteristic.Service.Uuid} "  +
                                    $"Characteristic UUID = {_characteristic.Uuid} - " +
                                    $"Failed to subscribe to ValueChanged");
            }

            return this;
        }

        private void OnValueChanged(
            GattCharacteristic sender,
            GattValueChangedEventArgs args)
        {
            var bytes = args.CharacteristicValue
                            .ToArray();

            var details = new ValueChangedDetails(sender.Uuid,
                                               bytes,
                                               args.Timestamp);

            _valueChanged.OnNext(details);
        }

        /// <inheritdoc />
        public Guid Uuid => _characteristic.Uuid;

        /// <inheritdoc />
        public GattCharacteristicProperties CharacteristicProperties => _characteristic.CharacteristicProperties;

        public IReadOnlyList<GattPresentationFormat> PresentationFormats => _characteristic.PresentationFormats;
        public Guid ServiceUuid => _characteristic.Service.Uuid; // maybe inject IGattDeviceServiceWrapper
        public string UserDescription => _characteristic.UserDescription;
        public GattProtectionLevel ProtectionLevel => _characteristic.ProtectionLevel;
        public ushort AttributeHandle => _characteristic.AttributeHandle;

        /// <inheritdoc />
        public async Task<GattWriteResult> WriteValueWithResultAsync(IBuffer buffer)
        {
            return await _characteristic.WriteValueWithResultAsync(buffer);
        }

        /// <inheritdoc />
        public async Task<GattCommunicationStatus> WriteValueAsync(IBuffer buffer)
        {
            return await _characteristic.WriteValueAsync(buffer);
        }

        /// <inheritdoc />
        public Task<GattReadResult> ReadValueAsync()
        {
            return _characteristic.ReadValueAsync()
                                      .AsTask();
        }

        public void Dispose()
        {
            _characteristic.ValueChanged -= OnValueChanged;
        }
    }

    public class ValueChangedDetails
    {
        public Guid              Uuid      { get; }
        public IEnumerable<byte> Value     { get; }
        public DateTimeOffset    Timestamp { get; }

        public ValueChangedDetails(
            Guid              uuid,
            IEnumerable<byte> value,
            DateTimeOffset    timestamp)
        {
            Uuid      = uuid;
            Value     = value;
            Timestamp = timestamp;
        }
    }
}