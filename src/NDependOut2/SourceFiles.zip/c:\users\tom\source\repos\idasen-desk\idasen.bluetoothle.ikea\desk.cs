﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Idasen.BluetoothLE.Ikea.Interfaces;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.Ikea
{
    public class Desk
        : IDesk
    {
        private readonly IDeskCharacteristics _deskCharacteristics;
        private readonly IDevice              _device;
        private readonly ILogger              _logger;

        private IDisposable _subscriber;

        public Desk(
            [NotNull] ILogger                           logger,
            [NotNull] Func<ISubject<IEnumerable<byte>>> subjectFactory,
            [NotNull] IDevice                           device,
            [NotNull] IDeskCharacteristics              deskCharacteristics)
        {
            Guard.ArgumentNotNull(logger,
                                  nameof(logger));
            Guard.ArgumentNotNull(subjectFactory,
                                  nameof(subjectFactory));
            Guard.ArgumentNotNull(device,
                                  nameof(device));
            Guard.ArgumentNotNull(deskCharacteristics,
                                  nameof(deskCharacteristics));

            _logger              = logger;
            _device              = device;
            _deskCharacteristics = deskCharacteristics;

            _device.GattServicesRefreshed
                   .Subscribe(OnGattServicesRefreshed);

            DeviceNameChanged = subjectFactory();
        }

        public void Connect()
        {
            _device.Connect();
        }

        /// <inheritdoc />
        public ISubject<IEnumerable<byte>> AppearanceChanged => _deskCharacteristics.GenericAccess
                                                                                    .AppearanceChanged;

        /// <inheritdoc />
        public ISubject<IEnumerable<byte>> ParametersChanged => _deskCharacteristics.GenericAccess
                                                                                    .ParametersChanged;

        /// <inheritdoc />
        public ISubject<IEnumerable<byte>> ResolutionChanged => _deskCharacteristics.GenericAccess
                                                                                    .ResolutionChanged;

        /// <inheritdoc />
        public ISubject<IEnumerable<byte>> DeviceNameChanged { get; }

        public void Dispose()
        {
            _subscriber?.Dispose();
        }

        private async void OnGattServicesRefreshed(GattCommunicationStatus status)
        {
            _logger.Information($"[{_device.DeviceId}] "                         +
                                $"ConnectionStatus: {_device.ConnectionStatus} " +
                                $"GattCommunicationStatus: {_device.GattCommunicationStatus}");

            _deskCharacteristics.Initialize(_device);

            _subscriber?.Dispose();

            _subscriber = _deskCharacteristics.GenericAccess
                                              .DeviceNameChanged
                                              .Subscribe(OnDeviceNameChanged);

            await _deskCharacteristics.Refresh();

            _logger.Information($"{_deskCharacteristics}");
        }

        private void OnDeviceNameChanged(IEnumerable<byte> value)
        {
            DeviceNameChanged.OnNext(value);
        }
    }
}