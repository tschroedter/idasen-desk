﻿using System;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.Ikea.Common
{
    public class ResourceNotFoundException
        : Exception     // todo duplicated code
    {
        public string ResourceName { get; }

        public ResourceNotFoundException(
            [NotNull]   string resourceName,
            [CanBeNull] string message)
            : base(message)
        {
            ResourceName = resourceName;
        }
    }
}