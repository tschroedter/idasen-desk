﻿using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Factories;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Factories
{
    public class ControlFactory // todo generic factory
        : IControlFactory
    {
        private readonly Control.Factory _factory;

        public ControlFactory([NotNull] Control.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }

        public IControl Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}