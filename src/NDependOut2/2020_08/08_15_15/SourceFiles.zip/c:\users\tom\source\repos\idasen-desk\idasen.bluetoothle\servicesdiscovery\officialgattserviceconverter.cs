﻿using System;
using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;

namespace Idasen.BluetoothLE.ServicesDiscovery
{
    public class OfficialGattServiceConverter
        : DefaultTypeConverter
    {
        public override object ConvertFromString(
            string        text,
            IReaderRow    row,
            MemberMapData memberMapData)
        {
            var number = text.Replace("0x",
                                      "",
                                      StringComparison.InvariantCulture);

            return ushort.TryParse(number,
                                   NumberStyles.HexNumber,
                                   CultureInfo.InvariantCulture,
                                   out var value)
                       ? value
                       : ushort.MaxValue;
        }

        public override string ConvertToString(
            object        value,
            IWriterRow    row,
            MemberMapData memberMapData)
        {
            return value.ToString();
        }
    }
}