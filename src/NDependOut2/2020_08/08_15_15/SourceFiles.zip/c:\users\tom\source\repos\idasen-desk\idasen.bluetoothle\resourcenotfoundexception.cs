﻿using System;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE
{
    public class ResourceNotFoundException : Exception
    {
        public string ResourceName { get; }

        public ResourceNotFoundException(
            [NotNull]   string resourceName,
            [CanBeNull] string message)
            : base(message)
        {
            ResourceName = resourceName;
        }
    }
}