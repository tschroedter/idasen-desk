﻿using System.Collections.Generic;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Unknowns
{
    public class ReferenceInput
        : UnknownBase, IReferenceInput
    {
        public IEnumerable<byte> Ctrl1 { get; } = RawArrayEmpty;
    }
}