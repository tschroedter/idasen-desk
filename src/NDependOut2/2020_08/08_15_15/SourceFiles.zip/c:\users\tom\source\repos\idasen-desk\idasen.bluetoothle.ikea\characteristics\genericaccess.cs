﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using System.Threading.Tasks;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Customs;
using Idasen.BluetoothLE.Ikea.Interfaces.Common;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.Ikea.Characteristics
{
    public class GenericAccess
        : CharacteristicBase,
          IGenericAccess
    {
        private const string CharacteristicDeviceName = "Device Name";
        private const string CharacteristicAppearance = "Appearance";
        private const string CharacteristicParameters = "Peripheral Preferred Connection Parameters";
        private const string CharacteristicResolution = "Central Address Resolution";

        private readonly IAllGattCharacteristicsProvider _allGattCharacteristicsProvider;

        public GenericAccess(
            ILogger                                   logger,
            IDevice                                   device,
            IGattCharacteristicsProviderFactory       providerFactory,
            IRawValueReader                           rawValueReader,
            IRawValueWriter                           valueWriter,
            [NotNull] Func<ISubject<byte[]>>          subjectFactory,
            [NotNull] IAllGattCharacteristicsProvider allGattCharacteristicsProvider)
            : base(logger,
                   device,
                   providerFactory,
                   rawValueReader,
                   valueWriter)
        {
            Guard.ArgumentNotNull(subjectFactory,
                                  nameof(subjectFactory));
            Guard.ArgumentNotNull(allGattCharacteristicsProvider,
                                  nameof(allGattCharacteristicsProvider));

            _allGattCharacteristicsProvider = allGattCharacteristicsProvider;

            DeviceNameChanged = subjectFactory();
            ResolutionChanged = subjectFactory();
            ParametersChanged = subjectFactory();
            AppearanceChanged = subjectFactory();
        }

        /// <inheritdoc />
        public ISubject<byte[]> AppearanceChanged { get; }

        /// <inheritdoc />
        public ISubject<byte[]> ParametersChanged { get; }

        /// <inheritdoc />
        public ISubject<byte[]> ResolutionChanged { get; }

        /// <inheritdoc />
        public ISubject<byte[]> DeviceNameChanged { get; }

        /// <inheritdoc />
        public override Guid GattServiceUuid { get; } = Guid.Parse("00001800-0000-1000-8000-00805F9B34FB");

        /// <inheritdoc />
        public IEnumerable<byte> RawResolution => TryGetValueOrEmpty(CharacteristicResolution);

        /// <inheritdoc />
        public IEnumerable<byte> RawParameters =>
            TryGetValueOrEmpty(CharacteristicParameters); // todo summary ConnectionParameters = RawPeripheralPreferredConnectionParameters

        /// <inheritdoc />
        public IEnumerable<byte> RawAppearance => TryGetValueOrEmpty(CharacteristicAppearance);

        /// <inheritdoc />
        public IEnumerable<byte> RawDeviceName => TryGetValueOrEmpty(CharacteristicDeviceName);

        public override async Task Refresh()
        {
            await base.Refresh();
        }

        protected override T WithMapping<T>() where T : class
        {
            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicDeviceName,
                                                           out var uuid))
                DescriptionToUuid[CharacteristicDeviceName] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicAppearance,
                                                           out uuid))
                DescriptionToUuid[CharacteristicAppearance] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicParameters,
                                                           out uuid))
                DescriptionToUuid[CharacteristicParameters] = uuid;

            if (_allGattCharacteristicsProvider.TryGetUuid(CharacteristicResolution,
                                                           out uuid))
                DescriptionToUuid[CharacteristicResolution] = uuid;

            return this as T;
        }
    }
}