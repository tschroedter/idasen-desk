﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Unknowns
{
    public class Control
        : UnknownBase, IControl
    {
        public IEnumerable<byte> RawControl2 { get; } = RawArrayEmpty;
        public IEnumerable<byte> RawControl3 { get; } = RawArrayEmpty;

        public Task<bool> TryWriteRawControl2(byte[] bytes)
        {
            return Task.FromResult(false);
        }
    }
}