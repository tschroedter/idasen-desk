﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using CsvHelper;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;

namespace Idasen.BluetoothLE.ServicesDiscovery
{
    /// <inheritdoc />
    public class OfficialGattServices
        : IOfficialGattServices
    {
        private const string OfficialGattCharacteristics =
            "Idasen.BluetoothLE.ServicesDiscovery.OfficalGattServices.txt";

        private readonly Dictionary<ushort, OfficialGattService> _dictionary =
            new Dictionary<ushort, OfficialGattService>();

        public OfficialGattServices()
        {
            Populate(ReadCsvFile());
        }

        private void Populate(IEnumerable<OfficialGattService> records)
        {
            foreach (var record in records)
            {
                _dictionary[record.AssignedNumber] = record;
            }
        }

        /// <inheritdoc />
        public IEnumerator<OfficialGattService> GetEnumerator()
        {
            return _dictionary.Values.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        /// <inheritdoc />
        public int Count => _dictionary.Count;

        /// <inheritdoc />
        public bool TryFindByUuid(Guid guid, out OfficialGattService gattService)
        {
            gattService = null;

            var number = guid.ToString("N")
                             .Substring(4, 4);

            ushort assignedNumber;

            try
            {
                assignedNumber = (ushort) Convert.ToInt32(number, 16);
            }
            catch (Exception)
            {
                return false;
            }

            return _dictionary.TryGetValue(assignedNumber,
                                           out gattService);
        }

        private static IEnumerable<OfficialGattService> ReadCsvFile()   // todo duplicated code
        {
            var stream = Assembly.GetExecutingAssembly()
                                 .GetManifestResourceStream(OfficialGattCharacteristics);

            if (stream == null)
                throw new ResourceNotFoundException(OfficialGattCharacteristics,
                                                    $"Can't find resource {OfficialGattCharacteristics}");

            using var reader = new StreamReader(stream);

            using var csv = new CsvReader(reader,
                                          CultureInfo.InvariantCulture);

            csv.Configuration.Delimiter = ",";
            csv.Configuration.RegisterClassMap<GattServiceCsvHelperMap>();

            var readCsvFile = csv.GetRecords<OfficialGattService>()
                                 .ToArray();

            return readCsvFile;
        }
    }
}