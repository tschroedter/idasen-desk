﻿using System.Collections.Generic;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Unknowns
{
    public class Dpg
        : UnknownBase, IDpg
    {
        public IEnumerable<byte> RawDpg { get; } = RawArrayEmpty;
    }
}