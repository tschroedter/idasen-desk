﻿using System.Collections.Generic;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Unknowns
{
    public class GenericAttribute
        : UnknownBase, IGenericAttribute
    {
        public IEnumerable<byte> RawServiceChanged { get; } = RawArrayEmpty;
    }
}