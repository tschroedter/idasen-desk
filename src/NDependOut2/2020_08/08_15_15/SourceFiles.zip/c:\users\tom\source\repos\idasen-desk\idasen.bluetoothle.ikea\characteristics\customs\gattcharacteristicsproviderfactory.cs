﻿using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Customs;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery.Wrappers;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Customs
{
    public class GattCharacteristicsProviderFactory
        : IGattCharacteristicsProviderFactory
    {
        private readonly GattCharacteristicProvider.Factory _factory;

        public GattCharacteristicsProviderFactory(
            [NotNull] GattCharacteristicProvider.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }

        public IGattCharacteristicProvider Create(
            IGattCharacteristicsResultWrapper wrapper)
        {
            return _factory(wrapper);
        }
    }
}