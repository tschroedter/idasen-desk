﻿using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics.Factories;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Factories
{
    public class GenericAccessFactory // todo generic factory
        : IGenericAccessFactory
    {
        private readonly IGenericAccess.Factory _factory;

        public GenericAccessFactory([NotNull] IGenericAccess.Factory factory)
        {
            Guard.ArgumentNotNull(factory,
                                  nameof(factory));

            _factory = factory;
        }

        public IGenericAccess Create([NotNull] IDevice device)
        {
            Guard.ArgumentNotNull(device,
                                  nameof(device));

            return _factory(device);
        }
    }
}