﻿using System;
using System.Reactive.Subjects;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Idasen.BluetoothLE.Ikea.Interfaces;
using Idasen.BluetoothLE.Interfaces.ServicesDiscovery;
using JetBrains.Annotations;
using Serilog;

namespace Idasen.BluetoothLE.Ikea
{
    public class Desk
        : IDesk
    {
        private readonly IDeskCharacteristics _deskCharacteristics;
        private readonly IDevice              _device;
        private readonly ILogger              _logger;

        public Desk(
            [NotNull] ILogger              logger,
            [NotNull] IDevice              device,
            [NotNull] IDeskCharacteristics deskCharacteristics)
        {
            Guard.ArgumentNotNull(logger,
                                  nameof(logger));
            Guard.ArgumentNotNull(device,
                                  nameof(device));
            Guard.ArgumentNotNull(deskCharacteristics,
                                  nameof(deskCharacteristics));

            _logger              = logger;
            _device              = device;
            _deskCharacteristics = deskCharacteristics;

            _device.GattServicesRefreshed
                   .Subscribe(OnGattServicesRefreshed);
        }

        public void Connect()
        {
            _device.Connect();
        }

        /// <inheritdoc />
        public ISubject<byte[]> AppearanceChanged => _deskCharacteristics.GenericAccess
                                                                         .AppearanceChanged;

        /// <inheritdoc />
        public ISubject<byte[]> ParametersChanged => _deskCharacteristics.GenericAccess
                                                                         .ParametersChanged;

        /// <inheritdoc />
        public ISubject<byte[]> ResolutionChanged => _deskCharacteristics.GenericAccess
                                                                         .ResolutionChanged;

        /// <inheritdoc />
        public ISubject<byte[]> DeviceNameChanged => _deskCharacteristics.GenericAccess
                                                                         .DeviceNameChanged;

        private async void OnGattServicesRefreshed(GattCommunicationStatus status)
        {
            _logger.Information($"[{_device.DeviceId}] "                         +
                                $"ConnectionStatus: {_device.ConnectionStatus} " +
                                $"GattCommunicationStatus: {_device.GattCommunicationStatus}");

            _deskCharacteristics.Initialize(_device);

            await _deskCharacteristics.Refresh();

            _logger.Information($"{_deskCharacteristics}");
        }
    }
}