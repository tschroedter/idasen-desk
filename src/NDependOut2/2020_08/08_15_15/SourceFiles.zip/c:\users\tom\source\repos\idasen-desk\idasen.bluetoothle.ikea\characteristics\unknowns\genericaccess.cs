﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Idasen.BluetoothLE.Ikea.Interfaces.Characteristics;

namespace Idasen.BluetoothLE.Ikea.Characteristics.Unknowns
{
    public class GenericAccess
        : UnknownBase, IGenericAccess
    {
        public GenericAccess(Func<ISubject<byte[]>> factory)
        {
            AppearanceChanged = factory();
            ParametersChanged = factory();
            ResolutionChanged = factory();
            DeviceNameChanged = factory();

            GattServiceUuid = Guid.Empty;
        }

        public IEnumerable<byte> RawResolution                { get; } = RawArrayEmpty;
        public IEnumerable<byte> RawParameters { get; } = RawArrayEmpty;
        public IEnumerable<byte> RawAppearance                              { get; } = RawArrayEmpty;
        public IEnumerable<byte> RawDeviceName                              { get; } = RawArrayEmpty;
        public ISubject<byte[]> AppearanceChanged { get; }
        public ISubject<byte[]> ParametersChanged { get; }
        public ISubject<byte[]> ResolutionChanged { get; }
        public ISubject<byte[]> DeviceNameChanged { get; }
        public Guid GattServiceUuid { get; }
    }
}