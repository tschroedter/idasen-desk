﻿using Idasen.BluetoothLE.Interfaces;
using Idasen.BluetoothLE.Interfaces.DevicesDiscovery;

namespace Idasen.BluetoothLE.DevicesDiscovery
{
    /// <inheritdoc />
    public class DeviceFactory
        : IDeviceFactory
    {
        private readonly Device.Factory _factory;

        public DeviceFactory(Device.Factory factory)
        {
            _factory = factory;
        }

        /// <inheritdoc />
        public IDevice Create(IDateTimeOffset broadcastTime,
                              ulong           address,
                              string          name,
                              short           rawSignalStrengthInDBm)
        {
            Guard.ArgumentNotNull(broadcastTime,
                                  nameof(broadcastTime));

            return _factory.Invoke(broadcastTime,
                                   address,
                                   name,
                                   rawSignalStrengthInDBm);
        }
    }
}