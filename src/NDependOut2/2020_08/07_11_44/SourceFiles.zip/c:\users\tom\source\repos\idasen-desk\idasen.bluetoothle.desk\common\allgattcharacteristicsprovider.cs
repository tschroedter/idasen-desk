﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using CsvHelper;
using Idasen.BluetoothLE.Desk.Interfaces.Common;
using JetBrains.Annotations;

namespace Idasen.BluetoothLE.Desk.Common
{
    public class AllGattCharacteristicsProvider
        : IAllGattCharacteristicsProvider
    {
        public const string OfficialGattCharacteristics =
            "Idasen.BluetoothLE.Desk.Common.OfficialGattCharacteristics.txt";

        private readonly Dictionary<string, Guid> _descriptionToUuid = new Dictionary<string, Guid>();
        private readonly Dictionary<Guid, string> _uuidToDescription = new Dictionary<Guid, string>();

        public AllGattCharacteristicsProvider()
        {
            Populate(ReadCsvFile());
        }

        public bool TryGetDescription(Guid       uuid,
                                      out string description)
        {
            return _uuidToDescription.TryGetValue(uuid, out description);
        }

        public bool TryGetUuid(string   description,
                               out Guid uuid)
        {
            return _descriptionToUuid.TryGetValue(description, out uuid);
        }

        private void Populate(IEnumerable<GattCharacteristic> records)
        {
            foreach (var record in records)
            {
                _uuidToDescription[Guid.Parse(record.Uuid)] = record.Name;
            }

            foreach (var (uuid, description) in _uuidToDescription)
            {
                _descriptionToUuid[description] = uuid;
            }
        }

        private IEnumerable<GattCharacteristic> ReadCsvFile()
        {
            var stream = Assembly.GetExecutingAssembly()
                                 .GetManifestResourceStream(OfficialGattCharacteristics);

            if (stream == null)
                throw new NullReferenceException($"Can't find resource {OfficialGattCharacteristics}");

            using var reader = new StreamReader(stream);

            using var csv = new CsvReader(reader,
                                          CultureInfo.InvariantCulture);

            csv.Configuration.Delimiter = ",";

            var readCsvFile = csv.GetRecords<GattCharacteristic>()
                                 .ToArray();

            return readCsvFile;
        }

        [UsedImplicitly]
        private class GattCharacteristic
        {
            [UsedImplicitly] public string Uuid { get; set; }

            [UsedImplicitly] public string Name { get; set; }
        }
    }
}